package com.viettel.caobang.dieuhanh.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class KpiLoadResult {
    data class Success(val payload: KpiPayload) : KpiLoadResult()
    data class Error(val message: String, val needsActivation: Boolean = false) : KpiLoadResult()
}

/**
 * V14 REALTIME AM REPORT - WEEKLY ACTUAL FIX
 * Đọc trực tiếp Google Sheets qua endpoint CSV (gviz).
 * Đây là chế độ chạy thử bỏ qua bảo mật: file Google Sheets phải cho phép đọc bằng liên kết.
 * Nếu không truy cập được, app tự dùng snapshot gần nhất để tránh trắng màn hình.
 */
object SecureKpiRepository {
    private const val PROGRESS_SHEET_ID = "1b-9aXAaRWfeMQVlXvEGneHNw7qyDud-zFzDrFw32Cn4"
    private const val WEEKLY_SHEET_ID = "1YAi3SgPzt0xVj8X-iE0bmKnWhL_CljFTGMkMqP9gvqg"
    private val AM_SHEETS = listOf("NUONGPM", "LANHT22", "HOAIBT4", "HUEHT16", "THAODP7", "QUYENLTN")

    var elapsedPercent: Double = 8.3
        private set
    var daysRemaining: Int = 22
        private set
    var amSnapshots: List<AmSnapshot> = snapshotAms()
        private set
    var lastWarning: String? = null
        private set

    private fun kpi(id: String, name: String, plan: Double, actual: Double, unit: String, owner: String, asOf: String) =
        KpiItem(id, name, plan, actual, unit, owner, asOf)

    private fun idFor(name: String): String = when {
        name.contains("Năng suất", true) -> "nang_suat_bh"
        name.contains("Giáo dục", true) -> "dt_gd_yt"
        name.contains("Dịch vụ mới", true) -> "dt_dv_moi"
        name.contains("truyền thống", true) -> "dt_truyen_thong"
        name.contains("Thâm nhập", true) -> "tham_nhap_mtl"
        name.contains("gia hạn", true) -> "gia_han"
        name.contains("Tendoo", true) -> "tendoo"
        name.contains("Mysign", true) || name.contains("MySign", true) -> "mysign"
        name.contains("M2M", true) -> "m2m_iot"
        name.contains("FTTH", true) -> "ftth"
        else -> name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_')
    }

    private fun cleanName(name: String): String = when {
        name.equals("TB Mysign", true) -> "MySign"
        name.equals("Tổng Thâm nhập vào DN MTL", true) -> "Thâm nhập DN MTL"
        name.equals("DT Dịch vụ mới", true) -> "Doanh thu dịch vụ mới"
        else -> name
    }

    private fun parseNumber(raw: String?): Double {
        var s = raw.orEmpty().trim().replace("%", "").replace("₫", "")
        if (s.isBlank()) return 0.0
        // vi-VN: 386.000.000 ; 8,3
        s = if (s.contains(',')) s.replace(".", "").replace(',', '.')
            else if (s.count { it == '.' } >= 1 && s.substringAfterLast('.').length == 3) s.replace(".", "")
            else s
        return s.replace(" ", "").toDoubleOrNull() ?: 0.0
    }

    private fun parseInt(raw: String?): Int = parseNumber(raw).toInt()

    private fun csvUrls(sheetName: String): List<String> {
        val sheet = URLEncoder.encode(sheetName, "UTF-8")
        return listOf(
            "https://docs.google.com/spreadsheets/d/$PROGRESS_SHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheet",
            "https://docs.google.com/spreadsheets/d/$PROGRESS_SHEET_ID/export?format=csv&sheet=$sheet"
        )
    }


    /**
     * Phần chi tiết hàng ngày của sheet AM nằm sau một khoảng trắng lớn.
     * GViz mặc định có thể chỉ trả về bảng KPI đầu tiên, vì vậy phải gọi riêng range A20:U60
     * để lấy cột TH ngày và tính TH tuần thực tế.
     */
    private fun dailyCsvUrls(sheetName: String): List<String> {
        val sheet = URLEncoder.encode(sheetName, "UTF-8")
        val range = URLEncoder.encode("A20:U60", "UTF-8")
        return listOf(
            "https://docs.google.com/spreadsheets/d/$PROGRESS_SHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheet&range=$range",
            "https://docs.google.com/spreadsheets/d/$PROGRESS_SHEET_ID/export?format=csv&sheet=$sheet&range=A20:U60"
        )
    }

    private fun weeklyCsvUrls(): List<String> {
        val sheet = URLEncoder.encode("Giao_CT_tuan", "UTF-8")
        return listOf(
            "https://docs.google.com/spreadsheets/d/$WEEKLY_SHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheet",
            "https://docs.google.com/spreadsheets/d/$WEEKLY_SHEET_ID/export?format=csv&sheet=$sheet"
        )
    }

    private fun weekNumber(reportDate: String): Int {
        val day = reportDate.substringBefore('/').toIntOrNull() ?: 1
        return when {
            day <= 6 -> 1
            day <= 13 -> 2
            day <= 20 -> 3
            day <= 27 -> 4
            else -> 5
        }
    }

    private fun weekBounds(week: Int): IntRange = when (week) {
        1 -> 1..6
        2 -> 7..13
        3 -> 14..20
        4 -> 21..27
        else -> 28..31
    }

    private data class WeeklyPlan(val plan: Double, val label: String)

    private fun parseWeeklyPlans(rows: List<List<String>>, week: Int): Map<String, Map<String, WeeklyPlan>> {
        val result = mutableMapOf<String, MutableMap<String, WeeklyPlan>>()
        val col = 10 + (week - 1)
        val header = rows.getOrNull(4)?.getOrNull(col).orEmpty()
        val label = header.lines().take(2).joinToString(" • ").ifBlank { "Tuần $week" }
        var currentAm = ""
        for (r in 5 until rows.size) {
            val row = rows[r]
            val rawAm = row.getOrNull(0).orEmpty().trim()
            if (rawAm.isNotBlank()) currentAm = rawAm.substringBefore("_NV_SME_CBG")
            if (currentAm.isBlank()) continue
            val name = row.getOrNull(2).orEmpty().trim()
            if (name.isBlank()) continue
            val id = idFor(name)
            val plan = parseNumber(row.getOrNull(col))
            result.getOrPut(currentAm) { mutableMapOf() }[id] = WeeklyPlan(plan, label)
        }
        return result
    }

    private fun weeklyActuals(rows: List<List<String>>, reportDate: String): Map<String, Double> {
        val week = weekNumber(reportDate)
        val bounds = weekBounds(week)
        val result = mutableMapOf<String, Double>()
        val dateHeader = rows.indexOfFirst { it.getOrNull(0)?.trim() == "Ngày" }
        if (dateHeader < 0) return result
        for (r in dateHeader + 2 until rows.size) {
            val date = rows[r].getOrNull(0).orEmpty().trim()
            val day = date.substringBefore('/').toIntOrNull() ?: continue
            if (day !in bounds) continue
            for (i in 0 until 10) {
                val cell = rows[r].getOrNull(1 + i * 2)
                val id = listOf("dt_truyen_thong","tham_nhap_mtl","gia_han","tendoo","mysign","dt_dv_moi","m2m_iot","ftth","dt_gd_yt","nang_suat_bh")[i]
                result[id] = (result[id] ?: 0.0) + parseNumber(cell)
            }
        }
        return result
    }

    private fun httpGet(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 20000
            readTimeout = 40000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Mozilla/5.0 (Android) ViettelCaoBangDieuHanh/1.4")
            setRequestProperty("Accept", "text/csv,text/plain,*/*")
            setRequestProperty("Cache-Control", "no-cache")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) throw IllegalStateException("Google Sheets trả HTTP $code")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (body.contains("accounts.google.com", true) || body.contains("ServiceLogin", true) || body.trimStart().startsWith("<!DOCTYPE html", true)) {
                throw IllegalStateException("Google Sheets đang yêu cầu đăng nhập")
            }
            if (body.isBlank()) throw IllegalStateException("Google Sheets trả dữ liệu rỗng")
            return body
        } finally {
            conn.disconnect()
        }
    }

    private fun httpGetAny(urls: List<String>): String {
        var last: Exception? = null
        repeat(2) {
            for (url in urls) {
                try { return httpGet(url) } catch (e: Exception) { last = e }
            }
        }
        throw IllegalStateException(last?.message ?: "Không kết nối được Google Sheets")
    }

    private fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                when {
                    c == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                    c == '"' -> quoted = false
                    else -> cell.append(c)
                }
            } else {
                when (c) {
                    '"' -> quoted = true
                    ',' -> { row.add(cell.toString()); cell.setLength(0) }
                    '\n' -> { row.add(cell.toString().trimEnd('\r')); cell.setLength(0); rows.add(row); row = mutableListOf() }
                    else -> cell.append(c)
                }
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString().trimEnd('\r')); rows.add(row) }
        return rows
    }

    private fun parseSheet(sheetName: String, owner: String, weeklyPlans: Map<String, Map<String, WeeklyPlan>> = emptyMap()): Pair<KpiPayload, AmSnapshot?> {
        val rows = parseCsv(httpGetAny(csvUrls(sheetName)))
        fun at(r: Int, c: Int): String = rows.getOrNull(r)?.getOrNull(c).orEmpty()
        val reportDate = at(2, 1).ifBlank { at(2, 0).substringAfter(':').trim() }
        val elapsed = parseNumber(at(3, 1)).takeIf { it > 0 } ?: elapsedPercent
        val remaining = parseInt(at(4, 1)).takeIf { it >= 0 } ?: daysRemaining

        // Không phụ thuộc vị trí dòng cố định. CSV/GViz đôi khi bỏ dòng trống,
        // nên quét toàn bộ sheet và nhận diện đúng 10 KPI theo tên chỉ tiêu.
        val expectedIds = setOf(
            "dt_truyen_thong", "tham_nhap_mtl", "gia_han", "tendoo", "mysign",
            "dt_dv_moi", "m2m_iot", "ftth", "dt_gd_yt", "nang_suat_bh"
        )
        val found = linkedMapOf<String, KpiItem>()
        for (r in rows.indices) {
            val rawName = at(r, 1).trim()
            if (rawName.isBlank()) continue
            val id = idFor(rawName)
            if (id !in expectedIds || id in found) continue
            val unit = at(r, 2).trim()
            val plan = parseNumber(at(r, 3))
            val actual = parseNumber(at(r, 4))
            found[id] = kpi(id, cleanName(rawName), plan, actual, unit, owner, reportDate)
        }
        val order = listOf(
            "dt_truyen_thong", "tham_nhap_mtl", "gia_han", "tendoo", "mysign",
            "dt_dv_moi", "m2m_iot", "ftth", "dt_gd_yt", "nang_suat_bh"
        )
        val items = order.mapNotNull { found[it] }.toMutableList()
        if (items.size < 10) {
            val missing = order.filterNot { it in found.keys }.joinToString(", ")
            throw IllegalStateException("Sheet $sheetName chỉ đọc được ${items.size}/10 KPI; thiếu: $missing")
        }
        val payload = KpiPayload(reportDate, "REALTIME • ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}", items.take(10))
        val week = weekNumber(reportDate)
        val actuals = if (sheetName == "Tong_hop") {
            emptyMap()
        } else {
            // Lấy riêng bảng TH ngày để bảo đảm có số liệu TH tuần thực tế.
            // Không dùng TH lũy kế tháng để suy diễn TH tuần.
            val dailyRows = parseCsv(httpGetAny(dailyCsvUrls(sheetName)))
            weeklyActuals(dailyRows, reportDate)
        }
        val plans = weeklyPlans[sheetName].orEmpty()
        val weekly = if (sheetName == "Tong_hop") emptyMap() else items.take(10).associate { item ->
            val wp = plans[item.id]
            item.id to WeeklyMetric(week, wp?.label ?: "Tuần $week", wp?.plan ?: 0.0, actuals[item.id] ?: 0.0)
        }
        val am = if (sheetName == "Tong_hop") null else AmSnapshot(sheetName, reportDate, elapsed, remaining, items.take(10), weekly)
        return payload to am
    }

    suspend fun load(context: Context): KpiLoadResult = withContext(Dispatchers.IO) {
        try {
            val (province, _) = parseSheet("Tong_hop", "Toàn tỉnh")
            val reportDate = province.reportDate
            var weeklyPlans: Map<String, Map<String, WeeklyPlan>> = emptyMap()
            var weeklyWarning: String? = null
            try {
                val weeklyRows = parseCsv(httpGetAny(weeklyCsvUrls()))
                weeklyPlans = parseWeeklyPlans(weeklyRows, weekNumber(reportDate))
            } catch (e: Exception) {
                weeklyWarning = "Không đọc được chỉ tiêu tuần: ${e.message}"
            }
            val freshAms = mutableListOf<AmSnapshot>()
            val amErrors = mutableListOf<String>()
            for (sheet in AM_SHEETS) {
                try {
                    val (_, am) = parseSheet(sheet, "AM $sheet", weeklyPlans)
                    if (am != null) freshAms.add(am)
                } catch (e: Exception) {
                    amErrors.add("$sheet: ${e.message}")
                    snapshotAms().firstOrNull { it.code == sheet }?.let { freshAms.add(it) }
                }
            }
            if (freshAms.isNotEmpty()) {
                amSnapshots = AM_SHEETS.mapNotNull { code -> freshAms.firstOrNull { it.code == code } }
                elapsedPercent = amSnapshots.firstOrNull()?.elapsedPercent ?: elapsedPercent
                daysRemaining = amSnapshots.firstOrNull()?.daysRemaining ?: daysRemaining
            }
            lastWarning = listOfNotNull(
                weeklyWarning,
                amErrors.takeIf { it.isNotEmpty() }?.let { "Một số AM dùng snapshot: ${it.joinToString(" | ")}" }
            ).joinToString(" • ").ifBlank { null }
            KpiLoadResult.Success(province)
        } catch (e: Exception) {
            lastWarning = "Không lấy được realtime: ${e.message}. Đang dùng snapshot gần nhất."
            KpiLoadResult.Success(snapshotPayload().copy(updatedAt = "OFFLINE • snapshot 05/09/2026"))
        }
    }

    suspend fun activate(context: Context, code: String): KpiLoadResult = load(context)

    private fun snapshotPayload(): KpiPayload = KpiPayload(
        "05/09/2026", "Snapshot 05/09/2026",
        listOf(
            kpi("dt_truyen_thong", "Doanh thu truyền thống", 386000000.0, 8413259.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("tham_nhap_mtl", "Thâm nhập DN MTL", 65.0, 4.0, "DN", "Toàn tỉnh", "05/09/2026"),
            kpi("gia_han", "Tổng gia hạn", 54.0, 1.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("tendoo", "Tendoo", 74.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("mysign", "MySign", 175.0, 13.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("dt_dv_moi", "Doanh thu dịch vụ mới", 18000000.0, 0.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("m2m_iot", "M2M/IoT", 77.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("ftth", "FTTH", 6.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("dt_gd_yt", "Doanh thu Giáo dục, Y tế", 51000000.0, 0.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("nang_suat_bh", "Năng suất bán hàng", 402000000.0, 8413259.0, "đồng", "Toàn tỉnh", "05/09/2026")
        )
    )

    private fun snapshotAms(): List<AmSnapshot> = listOf(
        snapshotAm("NUONGPM",65000000.0,4125000.0,11.0,2.0,9.0,0.0,13.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,4125000.0),
        snapshotAm("LANHT22",65000000.0,1159259.0,11.0,0.0,9.0,0.0,12.0,0.0,29.0,12.0,13.0,1.0,8500000.0,67000000.0,1159259.0),
        snapshotAm("HOAIBT4",64000000.0,0.0,11.0,0.0,9.0,0.0,13.0,0.0,30.0,1.0,13.0,1.0,8500000.0,67000000.0,0.0),
        snapshotAm("HUEHT16",64000000.0,0.0,11.0,0.0,9.0,0.0,12.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,0.0),
        snapshotAm("THAODP7",64000000.0,3129000.0,11.0,2.0,9.0,1.0,12.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,3129000.0),
        snapshotAm("QUYENLTN",64000000.0,0.0,10.0,0.0,9.0,0.0,12.0,0.0,29.0,0.0,12.0,1.0,8500000.0,67000000.0,0.0)
    )

    private fun snapshotWeek1Plans(code: String): Map<String, Double> = when (code) {
        "NUONGPM" -> mapOf("dt_truyen_thong" to 7609375.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 6.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 7984375.0)
        "LANHT22" -> mapOf("dt_truyen_thong" to 7980093.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 3.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 8355093.0)
        "HOAIBT4" -> mapOf("dt_truyen_thong" to 8000000.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 6.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 8500000.0)
        "HUEHT16" -> mapOf("dt_truyen_thong" to 8000000.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 6.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 850000.0)
        "THAODP7" -> mapOf("dt_truyen_thong" to 7608875.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 6.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 8108875.0)
        "QUYENLTN" -> mapOf("dt_truyen_thong" to 8000000.0, "tham_nhap_mtl" to 3.0, "gia_han" to 3.0, "tendoo" to 3.0, "mysign" to 6.0, "dt_dv_moi" to 375000.0, "m2m_iot" to 3.0, "ftth" to 1.0, "dt_gd_yt" to 1062500.0, "nang_suat_bh" to 8500000.0)
        else -> emptyMap()
    }

    private fun snapshotAm(code:String,dtP:Double,dtA:Double,mtlP:Double,mtlA:Double,renP:Double,renA:Double,tenP:Double,tenA:Double,myP:Double,myA:Double,m2mP:Double,ftthP:Double,gdP:Double,nsP:Double,nsA:Double):AmSnapshot {
        val o="AM $code"; val d="05/09/2026"
        val items = listOf(
            kpi("dt_truyen_thong","Doanh thu truyền thống",dtP,dtA,"đồng",o,d),
            kpi("tham_nhap_mtl","Thâm nhập DN MTL",mtlP,mtlA,"DN",o,d),
            kpi("gia_han","Tổng gia hạn",renP,renA,"TB",o,d),
            kpi("tendoo","Tendoo",tenP,tenA,"TB",o,d),
            kpi("mysign","MySign",myP,myA,"TB",o,d),
            kpi("dt_dv_moi","Doanh thu dịch vụ mới",3000000.0,0.0,"đồng",o,d),
            kpi("m2m_iot","M2M/IoT",m2mP,0.0,"TB",o,d),
            kpi("ftth","FTTH",ftthP,0.0,"TB",o,d),
            kpi("dt_gd_yt","Doanh thu Giáo dục, Y tế",gdP,0.0,"đồng",o,d),
            kpi("nang_suat_bh","Năng suất bán hàng",nsP,nsA,"đồng",o,d)
        )
        val plans = snapshotWeek1Plans(code)
        // Snapshot ngày 05/09 nằm trong tuần 1 (01-06/09), nên TH tuần đến 05/09
        // bằng tổng TH ngày 01-05/09, cũng chính là lũy kế tháng tại thời điểm snapshot.
        val weekly = items.associate { item ->
            item.id to WeeklyMetric(1, "Tuần 1 • 01–06/09", plans[item.id] ?: 0.0, item.actual)
        }
        return AmSnapshot(code,d,8.3,22,items,weekly)
    }
}

object TaskRepository {
    val tasks = listOf(
        WorkItem("Rà soát KPI ngày và chốt danh sách cảnh báo", "Phòng Kinh doanh", "17:00 hôm nay", TaskStatus.DOING, "Cao"),
        WorkItem("Bám đuổi KPI dưới tiến độ ngày đến từng AM", "GĐVTKV / GĐ Cụm KHDN", "18:00 hôm nay", TaskStatus.TODO, "Cao"),
        WorkItem("Cập nhật báo cáo cuối ngày", "Đầu mối báo cáo", "21:00 hôm nay", TaskStatus.TODO, "Trung bình")
    )
}

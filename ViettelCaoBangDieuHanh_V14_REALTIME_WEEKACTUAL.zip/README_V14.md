# V14 REALTIME - TH tuần thực tế

Bản V14 sửa lỗi thiếu số liệu TH tuần ở chi tiết từng AM.

- KH tuần: đọc từ sheet `Giao_CT_tuan`, đúng tuần hiện hành.
- TH tuần: đọc riêng phần chi tiết hàng ngày của từng AM (`A20:U60`) và cộng cột `TH ngày` trong đúng khoảng tuần.
- %HT tuần = TH tuần / KH tuần.
- KH tháng, lũy kế tháng, %HT tháng: giữ nguyên từ phần KPI đầu sheet AM.
- Khi realtime lỗi, snapshot 05/09 vẫn có TH tuần tuần 1 cho 6 AM để không hiển thị 0 sai.
- Giao diện chi tiết AM vẫn hiển thị đủ 10 KPI ngay sau khi chọn AM.

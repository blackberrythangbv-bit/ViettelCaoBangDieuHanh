package com.viettel.caobang.dieuhanh

import android.os.Bundle
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.viettel.caobang.dieuhanh.data.*
import com.viettel.caobang.dieuhanh.ui.theme.ViettelTheme
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViettelTheme { ViettelOperationsApp() } }
    }
}

@Composable
fun ViettelOperationsApp() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Điều hành", "KPI", "Công việc", "Báo cáo")
    var payload by remember { mutableStateOf<KpiPayload?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    var needsActivation by remember { mutableStateOf(false) }
    var activationCode by remember { mutableStateOf("") }

    LaunchedEffect(refreshKey) {
        loading = true
        when (val result = SecureKpiRepository.load(context)) {
            is KpiLoadResult.Success -> { payload = result.payload; error = null }
            is KpiLoadResult.Error -> { error = result.message; payload = null; needsActivation = result.needsActivation }
        }
        loading = false
    }

    Scaffold(
        topBar = {
            Surface(shadowElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("V", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 28.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ĐIỀU HÀNH VIETTEL CAO BẰNG", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Dashboard tác chiến • v0.9 REALTIME • Báo cáo ngày", color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton(onClick = { refreshKey++ }) {
                        Icon(Icons.Default.Refresh, "Làm mới", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {
                            Icon(
                                when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.DonutLarge; 2 -> Icons.Default.Task; else -> Icons.Default.Description },
                                null
                            )
                        },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        val modifier = Modifier.padding(padding)
        when (tab) {
            0 -> OperationsScreen(modifier, payload, loading, error, onRefresh = { refreshKey++ }, needsActivation, activationCode, { activationCode = it }) { code ->
                loading = true
                when (val r = SecureKpiRepository.activate(context, code)) {
                    is KpiLoadResult.Success -> { payload = r.payload; error = null; needsActivation = false; activationCode = "" }
                    is KpiLoadResult.Error -> { error = r.message; needsActivation = r.needsActivation }
                }
                loading = false
            }
            1 -> KpiScreen(modifier, payload, loading, error, onRefresh = { refreshKey++ }, needsActivation, activationCode, { activationCode = it }) { code ->
                loading = true
                when (val r = SecureKpiRepository.activate(context, code)) {
                    is KpiLoadResult.Success -> { payload = r.payload; error = null; needsActivation = false; activationCode = "" }
                    is KpiLoadResult.Error -> { error = r.message; needsActivation = r.needsActivation }
                }
                loading = false
            }
            2 -> TasksScreen(modifier)
            else -> ReportsScreen(modifier, payload, error)
        }
    }
}

@Composable
fun OperationsScreen(modifier: Modifier, payload: KpiPayload?, loading: Boolean, error: String?, onRefresh: () -> Unit, needsActivation: Boolean, activationCode: String, onCodeChange: (String)->Unit, onActivate: suspend (String)->Unit) {
    val scope = rememberCoroutineScope()
    val kpis = payload?.items.orEmpty()
    val elapsed = SecureKpiRepository.elapsedPercent
    val red = kpis.count { it.progress < elapsed * 0.8 }
    val yellow = kpis.count { it.progress >= elapsed * 0.8 && it.progress < elapsed }
    val green = kpis.count { it.progress >= elapsed }

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Tổng quan hôm nay", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(payload?.reportDate?.let { "Số liệu ngày $it" } ?: "Đang lấy KPI trực tiếp từ Google Sheets", color = Color.Gray)
        }
        if (loading) item { LoadingCard() }
        SecureKpiRepository.lastWarning?.let { warning -> item { AssistChip(onClick = {}, label = { Text(warning, fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Warning, null) }) } }
        if (error != null) item { if (needsActivation) ActivationCard(error, activationCode, onCodeChange) { scope.launch { onActivate(activationCode) } } else SecureConfigCard(error, onRefresh) }
        if (kpis.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("Đỏ", red.toString(), Color(0xFFD32F2F), Modifier.weight(1f))
                    StatCard("Vàng", yellow.toString(), Color(0xFFF9A825), Modifier.weight(1f))
                    StatCard("Xanh", green.toString(), Color(0xFF2E7D32), Modifier.weight(1f))
                }
            }
            item { SectionTitle("Cảnh báo cần bám đuổi") }
            items(kpis.sortedBy { it.progress }.take(3)) { KpiDonutCard(it, SecureKpiRepository.elapsedPercent) }
        }
        item { SectionTitle("Việc trọng tâm") }
        items(TaskRepository.tasks) { TaskRow(it) }
    }
}

@Composable
fun KpiScreen(modifier: Modifier, payload: KpiPayload?, loading: Boolean, error: String?, onRefresh: () -> Unit, needsActivation: Boolean, activationCode: String, onCodeChange: (String)->Unit, onActivate: suspend (String)->Unit) {
    val scope = rememberCoroutineScope()
    val kpis = payload?.items.orEmpty()
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dashboard KPI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Đánh giá theo tiến độ tháng đã qua ${fmt(SecureKpiRepository.elapsedPercent)}%", color = Color.Gray, fontSize = 12.sp)
                }
                if (!payload?.updatedAt.isNullOrBlank()) Text(payload!!.updatedAt, fontSize = 10.sp, color = Color.Gray)
            }
        }
        if (loading) item { LoadingCard() }
        SecureKpiRepository.lastWarning?.let { warning -> item { AssistChip(onClick = {}, label = { Text(warning, fontSize = 11.sp) }, leadingIcon = { Icon(Icons.Default.Warning, null) }) } }
        if (error != null) item { if (needsActivation) ActivationCard(error, activationCode, onCodeChange) { scope.launch { onActivate(activationCode) } } else SecureConfigCard(error, onRefresh) }
        items(kpis) { KpiDonutCard(it, SecureKpiRepository.elapsedPercent) }
    }
}

@Composable
fun TasksScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Giao việc & Deadline", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Theo dõi đầu mối, trạng thái và việc quá hạn.", color = Color.Gray)
        }
        items(TaskRepository.tasks) { TaskRow(it) }
    }
}

@Composable
fun ReportsScreen(modifier: Modifier, payload: KpiPayload?, error: String?) {
    var showDaily by remember { mutableStateOf(false) }
    if (showDaily) {
        DailyKpiReportScreen(modifier, payload, onBack = { showDaily = false })
        return
    }

    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Báo cáo nhanh", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(if (payload != null) "Nguồn: Google Sheets realtime • ${payload.reportDate}" else "Chưa có dữ liệu KPI.", color = Color.Gray)
        if (error != null) Text(error, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
        ReportCard("Báo cáo KPI ngày", "Toàn tỉnh + chi tiết 6 AM • tiến độ • cảnh báo", Icons.Default.Today) { showDaily = true }
        ReportCard("Báo cáo KPI tuần", "So sánh kế hoạch tuần và thực hiện", Icons.Default.DateRange)
        ReportCard("Danh sách cảnh báo", "KPI dưới tiến độ ngày và nhiệm vụ quá hạn", Icons.Default.Warning)
    }
}

@Composable
fun DailyKpiReportScreen(modifier: Modifier, payload: KpiPayload?, onBack: () -> Unit) {
    val all = payload?.items.orEmpty()
    val elapsed = SecureKpiRepository.elapsedPercent
    val ams = SecureKpiRepository.amSnapshots
    var selectedAm by remember { mutableStateOf(ams.firstOrNull()?.code ?: "") }
    val selected = ams.firstOrNull { it.code == selectedAm }
    val onTrack = all.count { it.progress >= elapsed }
    val behind = all.size - onTrack

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Quay lại") }
                Column {
                    Text("BÁO CÁO KPI NGÀY", fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("Kênh Doanh nghiệp số • Viettel Cao Bằng", color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Text("Ngày báo cáo: ${payload?.reportDate ?: "05/09/2026"}", fontWeight = FontWeight.SemiBold)
                    Text("Thời gian tháng đã qua: ${fmt(elapsed)}% • Còn ${SecureKpiRepository.daysRemaining} ngày", color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatCard("Đạt tiến độ", onTrack.toString(), Color(0xFF2E7D32), Modifier.weight(1f))
                        StatCard("Chưa đạt", behind.toString(), Color(0xFFD32F2F), Modifier.weight(1f))
                        StatCard("AM", ams.size.toString(), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                    }
                }
            }
        }
        item { SectionTitle("1. Kết quả toàn tỉnh") }
        items(all) { DailyProgressRow(it, elapsed) }

        item { SectionTitle("2. Tổng hợp đến từng AM") }
        items(ams) { AmSummaryCard(it) }

        item { SectionTitle("3. Xếp hạng AM theo năng suất bán hàng") }
        items(ams.sortedByDescending { it.items.first { k -> k.id == "nang_suat_bh" }.progress }.mapIndexed { idx, am -> idx + 1 to am }) { ranked ->
            val rank = ranked.first
            val am = ranked.second
            val ns = am.items.first { it.id == "nang_suat_bh" }
            Card(shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("#$rank", fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.width(42.dp))
                    Column(Modifier.weight(1f)) {
                        Text(am.code, fontWeight = FontWeight.Bold)
                        Text("TH ${fmt(ns.actual)}/${fmt(ns.plan)} đồng", fontSize = 12.sp, color = Color.Gray)
                    }
                    Text(pct(ns.progress), color = dailyColor(ns.progress, am.elapsedPercent), fontWeight = FontWeight.Black)
                }
            }
        }

        item { SectionTitle("4. Chi tiết KPI theo AM – tuần & tháng") }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ams) { am ->
                    FilterChip(
                        selected = selectedAm == am.code,
                        onClick = { selectedAm = am.code },
                        label = { Text(am.code) }
                    )
                }
            }
        }
        if (selected != null) {
            item {
                Text("AM ${selected.code} • ${selected.reportDate}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text("So với tiến độ thời gian ${fmt(selected.elapsedPercent)}%", color = Color.Gray, fontSize = 12.sp)
            }
            items(selected.items) { kpi ->
                WeeklyMonthlyProgressRow(kpi, selected.weekly[kpi.id], selected.elapsedPercent)
            }
        }

        item { SectionTitle("5. Cảnh báo điều hành") }
        item {
            val weakAm = ams.sortedBy { am -> am.items.first { it.id == "nang_suat_bh" }.progress }
            Card(shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Ưu tiên bám đuổi", fontWeight = FontWeight.Bold)
                    Text("• Toàn tỉnh có $behind/${all.size} KPI chưa đạt tiến độ ngày ${fmt(elapsed)}%.")
                    weakAm.take(3).forEach { am ->
                        val ns = am.items.first { it.id == "nang_suat_bh" }
                        Text("• AM ${am.code}: Năng suất bán hàng ${pct(ns.progress)} (${fmt(ns.actual)}/${fmt(ns.plan)} đồng).", fontSize = 12.sp)
                    }
                    Text("• Dữ liệu được làm mới trực tiếp từ bảng tiến độ và bảng giao chỉ tiêu tuần; nếu nguồn không truy cập được app sẽ hiện cảnh báo.", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun WeeklyMonthlyProgressRow(kpi: KpiItem, weekly: WeeklyMetric?, elapsedPercent: Double) {
    val monthColor = if (kpi.progress >= elapsedPercent) Color(0xFF2E7D32) else Color(0xFFD32F2F)
    val weekProgress = weekly?.progress ?: 0.0
    val weekColor = when {
        weekly == null || weekly.plan <= 0.0 -> Color.Gray
        weekProgress >= 100.0 -> Color(0xFF2E7D32)
        weekProgress >= 80.0 -> Color(0xFFF9A825)
        else -> Color(0xFFD32F2F)
    }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(kpi.name, fontWeight = FontWeight.Black, fontSize = 16.sp)
            if (weekly != null) {
                Text(weekly.weekLabel, color = Color.Gray, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MetricMini("KH tuần", fmt(weekly.plan), Modifier.weight(1f))
                    MetricMini("TH tuần", fmt(weekly.actual), Modifier.weight(1f))
                    MetricMini("%HT tuần", pct(weekProgress), Modifier.weight(1f), weekColor)
                }
            } else {
                Text("Chưa lấy được chỉ tiêu tuần", color = Color.Gray, fontSize = 12.sp)
            }
            HorizontalDivider()
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                MetricMini("KH tháng", fmt(kpi.plan), Modifier.weight(1f))
                MetricMini("Lũy kế tháng", fmt(kpi.actual), Modifier.weight(1f))
                MetricMini("%HT tháng", pct(kpi.progress), Modifier.weight(1f), monthColor)
            }
            Text("Đơn vị: ${kpi.unit}", color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
fun MetricMini(label: String, value: String, modifier: Modifier = Modifier, valueColor: Color = Color.Unspecified) {
    Surface(modifier = modifier, shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)) {
        Column(Modifier.padding(horizontal = 8.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.Black, color = valueColor, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun DailyProgressRow(kpi: KpiItem, elapsedPercent: Double) {
    val ok = kpi.progress >= elapsedPercent
    val color = if (ok) Color(0xFF2E7D32) else Color(0xFFD32F2F)
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(kpi.name, fontWeight = FontWeight.Bold)
                    Text("KH ${fmt(kpi.plan)} ${kpi.unit} • TH ${fmt(kpi.actual)} ${kpi.unit}", color = Color.Gray, fontSize = 12.sp)
                }
                Text(pct(kpi.progress), color = color, fontWeight = FontWeight.Black, fontSize = 18.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (kpi.progress / 100.0).coerceIn(0.0, 1.0).toFloat() },
                modifier = Modifier.fillMaxWidth().height(7.dp),
                color = color,
                trackColor = color.copy(alpha = 0.12f)
            )
            Spacer(Modifier.height(6.dp))
            Text(if (ok) "Đạt tiến độ ngày" else "Không đạt tiến độ ngày", color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun AmSummaryCard(am: AmSnapshot) {
    val ns = am.items.first { it.id == "nang_suat_bh" }
    val dt = am.items.first { it.id == "dt_truyen_thong" }
    val active = am.items.count { it.actual > 0.0 }
    val onTrack = am.items.count { it.progress >= am.elapsedPercent }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(am.code, fontWeight = FontWeight.Black, fontSize = 18.sp, modifier = Modifier.weight(1f))
                val c = if (ns.progress >= am.elapsedPercent) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                Text("NSBH ${pct(ns.progress)}", color = c, fontWeight = FontWeight.Bold)
            }
            Text("Doanh thu truyền thống: ${fmt(dt.actual)}/${fmt(dt.plan)} đồng • ${pct(dt.progress)}", fontSize = 12.sp)
            am.weekly["nang_suat_bh"]?.let { w ->
                Text("Tuần: NSBH ${fmt(w.actual)}/${fmt(w.plan)} đồng • ${pct(w.progress)}", fontSize = 12.sp)
            }
            Text("KPI có phát sinh: $active/10 • KPI đạt tiến độ ngày: $onTrack/10", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun KpiDonutCard(kpi: KpiItem, elapsedPercent: Double = SecureKpiRepository.elapsedPercent) {
    val p = kpi.progress
    val color = dailyColor(p, elapsedPercent)
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DonutProgress(progress = p, color = color, modifier = Modifier.size(104.dp))
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text(kpi.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text(kpi.owner, color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("KH: ${fmt(kpi.plan)} ${kpi.unit}", fontSize = 13.sp)
                Text("TH: ${fmt(kpi.actual)} ${kpi.unit}", fontSize = 13.sp)
                if (kpi.asOf.isNotBlank()) Text("Cập nhật: ${kpi.asOf}", fontSize = 10.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50)) {
                    Text(dailyStatus(p, elapsedPercent), color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                }
            }
        }
    }
}

@Composable
fun DonutProgress(progress: Double, color: Color, modifier: Modifier = Modifier) {
    val safe = progress.coerceIn(0.0, 100.0).toFloat()
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round)
            val inset = stroke.width / 2f
            val arcSize = Size(size.width - stroke.width, size.height - stroke.width)
            drawArc(
                color = color.copy(alpha = 0.14f), startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = stroke
            )
            drawArc(
                color = color, startAngle = -90f, sweepAngle = 360f * (safe / 100f), useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = stroke
            )
        }
        Text(pct(progress), fontSize = 21.sp, fontWeight = FontWeight.Black, color = color, textAlign = TextAlign.Center)
    }
}

@Composable
fun LoadingCard() {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
            Spacer(Modifier.width(12.dp))
            Text("Đang nạp KPI thực tế…")
        }
    }
}

@Composable
fun ActivationCard(message: String, code: String, onCodeChange: (String)->Unit, onActivate: ()->Unit) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AdminPanelSettings, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp)); Text("Kích hoạt thiết bị", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp)); Text(message, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = code, onValueChange = onCodeChange, label = { Text("Mã kích hoạt nội bộ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = onActivate, enabled = code.isNotBlank()) { Text("Kích hoạt") }
        }
    }
}

@Composable
fun SecureConfigCard(message: String, onRefresh: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Chế độ dữ liệu riêng tư", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Thử lại") }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, fontSize = 22.sp, color = accent)
            Text(title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun TaskRow(task: WorkItem) {
    val statusText = when(task.status) { TaskStatus.TODO -> "Chưa làm"; TaskStatus.DOING -> "Đang làm"; TaskStatus.DONE -> "Hoàn thành"; TaskStatus.OVERDUE -> "Quá hạn" }
    val color = when(task.status) { TaskStatus.TODO -> Color.Gray; TaskStatus.DOING -> Color(0xFF1565C0); TaskStatus.DONE -> Color(0xFF2E7D32); TaskStatus.OVERDUE -> Color(0xFFD32F2F) }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(task.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                AssistChip(onClick = {}, label = { Text(statusText, color = color, fontSize = 11.sp) })
            }
            Text("${task.owner} • Deadline: ${task.deadline} • ${task.priority}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable fun SectionTitle(text: String) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

@Composable
fun ReportCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit = {}) {
    Card(onClick = onClick, shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = Color.Gray) }
            Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
        }
    }
}

private fun dailyColor(p: Double, elapsed: Double): Color = when {
    p < elapsed * 0.8 -> Color(0xFFD32F2F)
    p < elapsed -> Color(0xFFF9A825)
    else -> Color(0xFF2E7D32)
}
private fun dailyStatus(p: Double, elapsed: Double): String = when {
    p < elapsed * 0.8 -> "Chậm tiến độ"
    p < elapsed -> "Cần bám đuổi"
    else -> "Đạt tiến độ ngày"
}
private fun fmt(v: Double): String = java.text.NumberFormat.getNumberInstance(java.util.Locale("vi", "VN")).apply { maximumFractionDigits = 1 }.format(v)
private fun pct(v: Double): String = if (v < 10.0 && v != 0.0) String.format(java.util.Locale.US, "%.1f%%", v) else "${v.roundToInt()}%"

package com.viettel.caobang.dieuhanh.data

data class KpiItem(
    val id: String,
    val name: String,
    val plan: Double,
    val actual: Double,
    val unit: String,
    val owner: String = "DNS",
    val asOf: String = ""
) {
    val progress: Double get() = if (plan <= 0.0) 0.0 else actual / plan * 100.0
}

data class KpiPayload(
    val reportDate: String,
    val updatedAt: String,
    val items: List<KpiItem>
)

data class AmSnapshot(
    val code: String,
    val reportDate: String,
    val elapsedPercent: Double,
    val daysRemaining: Int,
    val items: List<KpiItem>
)

enum class TaskStatus { TODO, DOING, DONE, OVERDUE }

data class WorkItem(
    val title: String,
    val owner: String,
    val deadline: String,
    val status: TaskStatus,
    val priority: String
)

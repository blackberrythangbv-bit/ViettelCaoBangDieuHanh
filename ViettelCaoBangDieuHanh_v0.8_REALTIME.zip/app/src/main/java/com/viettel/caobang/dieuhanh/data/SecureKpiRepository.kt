package com.viettel.caobang.dieuhanh.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class KpiLoadResult {
    data class Success(val payload: KpiPayload) : KpiLoadResult()
    data class Error(val message: String, val needsActivation: Boolean = false) : KpiLoadResult()
}

/**
 * v0.8 REALTIME TRIAL
 * Đọc trực tiếp Google Sheets qua endpoint CSV (gviz).
 * Đây là chế độ chạy thử bỏ qua bảo mật: file Google Sheets phải cho phép đọc bằng liên kết.
 * Nếu không truy cập được, app tự dùng snapshot gần nhất để tránh trắng màn hình.
 */
object SecureKpiRepository {
    private const val PROGRESS_SHEET_ID = "1b-9aXAaRWfeMQVlXvEGneHNw7qyDud-zFzDrFw32Cn4"
    private val AM_SHEETS = listOf("NUONGPM", "LANHT22", "HOAIBT4", "HUEHT16", "THAODP7", "QUYENLTN")

    var elapsedPercent: Double = 8.3
        private set
    var daysRemaining: Int = 22
        private set
    var amSnapshots: List<AmSnapshot> = snapshotAms()
        private set
    var lastWarning: String? = null
        private set

    private fun kpi(id: String, name: String, plan: Double, actual: Double, unit: String, owner: String, asOf: String) =
        KpiItem(id, name, plan, actual, unit, owner, asOf)

    private fun idFor(name: String): String = when {
        name.contains("Năng suất", true) -> "nang_suat_bh"
        name.contains("Giáo dục", true) -> "dt_gd_yt"
        name.contains("Dịch vụ mới", true) -> "dt_dv_moi"
        name.contains("truyền thống", true) -> "dt_truyen_thong"
        name.contains("Thâm nhập", true) -> "tham_nhap_mtl"
        name.contains("gia hạn", true) -> "gia_han"
        name.contains("Tendoo", true) -> "tendoo"
        name.contains("Mysign", true) || name.contains("MySign", true) -> "mysign"
        name.contains("M2M", true) -> "m2m_iot"
        name.contains("FTTH", true) -> "ftth"
        else -> name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_')
    }

    private fun cleanName(name: String): String = when {
        name.equals("TB Mysign", true) -> "MySign"
        name.equals("Tổng Thâm nhập vào DN MTL", true) -> "Thâm nhập DN MTL"
        name.equals("DT Dịch vụ mới", true) -> "Doanh thu dịch vụ mới"
        else -> name
    }

    private fun parseNumber(raw: String?): Double {
        var s = raw.orEmpty().trim().replace("%", "").replace("₫", "")
        if (s.isBlank()) return 0.0
        // vi-VN: 386.000.000 ; 8,3
        s = if (s.contains(',')) s.replace(".", "").replace(',', '.')
            else if (s.count { it == '.' } >= 1 && s.substringAfterLast('.').length == 3) s.replace(".", "")
            else s
        return s.replace(" ", "").toDoubleOrNull() ?: 0.0
    }

    private fun parseInt(raw: String?): Int = parseNumber(raw).toInt()

    private fun csvUrl(sheetName: String): String {
        val sheet = URLEncoder.encode(sheetName, "UTF-8")
        return "https://docs.google.com/spreadsheets/d/$PROGRESS_SHEET_ID/gviz/tq?tqx=out:csv&sheet=$sheet"
    }

    private fun httpGet(url: String): String {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8000
            readTimeout = 12000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "ViettelCaoBangDieuHanh/0.8")
            setRequestProperty("Accept", "text/csv,text/plain,*/*")
        }
        val code = conn.responseCode
        if (code !in 200..299) throw IllegalStateException("Google Sheets trả HTTP $code")
        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (body.contains("accounts.google.com", true) || body.contains("ServiceLogin", true) || body.trimStart().startsWith("<!DOCTYPE html", true)) {
            throw IllegalStateException("Google Sheets đang yêu cầu đăng nhập")
        }
        return body
    }

    private fun parseCsv(text: String): List<List<String>> {
        val rows = mutableListOf<MutableList<String>>()
        var row = mutableListOf<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                when {
                    c == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                    c == '"' -> quoted = false
                    else -> cell.append(c)
                }
            } else {
                when (c) {
                    '"' -> quoted = true
                    ',' -> { row.add(cell.toString()); cell.setLength(0) }
                    '\n' -> { row.add(cell.toString().trimEnd('\r')); cell.setLength(0); rows.add(row); row = mutableListOf() }
                    else -> cell.append(c)
                }
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString().trimEnd('\r')); rows.add(row) }
        return rows
    }

    private fun parseSheet(sheetName: String, owner: String): Pair<KpiPayload, AmSnapshot?> {
        val rows = parseCsv(httpGet(csvUrl(sheetName)))
        fun at(r: Int, c: Int): String = rows.getOrNull(r)?.getOrNull(c).orEmpty()
        val reportDate = at(2, 1).ifBlank { at(2, 0).substringAfter(':').trim() }
        val elapsed = parseNumber(at(3, 1)).takeIf { it > 0 } ?: elapsedPercent
        val remaining = parseInt(at(4, 1)).takeIf { it >= 0 } ?: daysRemaining

        val items = mutableListOf<KpiItem>()
        for (r in 7 until minOf(rows.size, 40)) {
            val stt = at(r, 0).trim()
            if (stt.toIntOrNull() == null) {
                if (items.isNotEmpty()) break
                continue
            }
            val rawName = at(r, 1).trim()
            if (rawName.isBlank()) continue
            val unit = at(r, 2).trim()
            val plan = parseNumber(at(r, 3))
            val actual = parseNumber(at(r, 4))
            val name = cleanName(rawName)
            items.add(kpi(idFor(rawName), name, plan, actual, unit, owner, reportDate))
        }
        if (items.size < 10) throw IllegalStateException("Sheet $sheetName chỉ đọc được ${items.size}/10 KPI")
        val payload = KpiPayload(reportDate, "REALTIME • ${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}", items.take(10))
        val am = if (sheetName == "Tong_hop") null else AmSnapshot(sheetName, reportDate, elapsed, remaining, items.take(10))
        return payload to am
    }

    suspend fun load(context: Context): KpiLoadResult = withContext(Dispatchers.IO) {
        try {
            val (province, _) = parseSheet("Tong_hop", "Toàn tỉnh")
            val freshAms = mutableListOf<AmSnapshot>()
            for (sheet in AM_SHEETS) {
                val (_, am) = parseSheet(sheet, "AM $sheet")
                if (am != null) freshAms.add(am)
            }
            if (freshAms.isNotEmpty()) {
                amSnapshots = freshAms
                elapsedPercent = freshAms.first().elapsedPercent
                daysRemaining = freshAms.first().daysRemaining
            }
            lastWarning = null
            KpiLoadResult.Success(province)
        } catch (e: Exception) {
            lastWarning = "Không lấy được realtime: ${e.message}. Đang dùng snapshot gần nhất."
            KpiLoadResult.Success(snapshotPayload().copy(updatedAt = "OFFLINE • snapshot 05/09/2026"))
        }
    }

    suspend fun activate(context: Context, code: String): KpiLoadResult = load(context)

    private fun snapshotPayload(): KpiPayload = KpiPayload(
        "05/09/2026", "Snapshot 05/09/2026",
        listOf(
            kpi("dt_truyen_thong", "Doanh thu truyền thống", 386000000.0, 8413259.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("tham_nhap_mtl", "Thâm nhập DN MTL", 65.0, 4.0, "DN", "Toàn tỉnh", "05/09/2026"),
            kpi("gia_han", "Tổng gia hạn", 54.0, 1.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("tendoo", "Tendoo", 74.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("mysign", "MySign", 175.0, 13.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("dt_dv_moi", "Doanh thu dịch vụ mới", 18000000.0, 0.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("m2m_iot", "M2M/IoT", 77.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("ftth", "FTTH", 6.0, 0.0, "TB", "Toàn tỉnh", "05/09/2026"),
            kpi("dt_gd_yt", "Doanh thu Giáo dục, Y tế", 51000000.0, 0.0, "đồng", "Toàn tỉnh", "05/09/2026"),
            kpi("nang_suat_bh", "Năng suất bán hàng", 402000000.0, 8413259.0, "đồng", "Toàn tỉnh", "05/09/2026")
        )
    )

    private fun snapshotAms(): List<AmSnapshot> = listOf(
        snapshotAm("NUONGPM",65000000.0,4125000.0,11.0,2.0,9.0,0.0,13.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,4125000.0),
        snapshotAm("LANHT22",65000000.0,1159259.0,11.0,0.0,9.0,0.0,12.0,0.0,29.0,12.0,13.0,1.0,8500000.0,67000000.0,1159259.0),
        snapshotAm("HOAIBT4",64000000.0,0.0,11.0,0.0,9.0,0.0,13.0,0.0,30.0,1.0,13.0,1.0,8500000.0,67000000.0,0.0),
        snapshotAm("HUEHT16",64000000.0,0.0,11.0,0.0,9.0,0.0,12.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,0.0),
        snapshotAm("THAODP7",64000000.0,3129000.0,11.0,2.0,9.0,1.0,12.0,0.0,29.0,0.0,13.0,1.0,8500000.0,67000000.0,3129000.0),
        snapshotAm("QUYENLTN",64000000.0,0.0,10.0,0.0,9.0,0.0,12.0,0.0,29.0,0.0,12.0,1.0,8500000.0,67000000.0,0.0)
    )

    private fun snapshotAm(code:String,dtP:Double,dtA:Double,mtlP:Double,mtlA:Double,renP:Double,renA:Double,tenP:Double,tenA:Double,myP:Double,myA:Double,m2mP:Double,ftthP:Double,gdP:Double,nsP:Double,nsA:Double):AmSnapshot {
        val o="AM $code"; val d="05/09/2026"
        return AmSnapshot(code,d,8.3,22,listOf(
            kpi("dt_truyen_thong","Doanh thu truyền thống",dtP,dtA,"đồng",o,d),
            kpi("tham_nhap_mtl","Thâm nhập DN MTL",mtlP,mtlA,"DN",o,d),
            kpi("gia_han","Tổng gia hạn",renP,renA,"TB",o,d),
            kpi("tendoo","Tendoo",tenP,tenA,"TB",o,d),
            kpi("mysign","MySign",myP,myA,"TB",o,d),
            kpi("dt_dv_moi","Doanh thu dịch vụ mới",3000000.0,0.0,"đồng",o,d),
            kpi("m2m_iot","M2M/IoT",m2mP,0.0,"TB",o,d),
            kpi("ftth","FTTH",ftthP,0.0,"TB",o,d),
            kpi("dt_gd_yt","Doanh thu Giáo dục, Y tế",gdP,0.0,"đồng",o,d),
            kpi("nang_suat_bh","Năng suất bán hàng",nsP,nsA,"đồng",o,d)
        ))
    }
}

object TaskRepository {
    val tasks = listOf(
        WorkItem("Rà soát KPI ngày và chốt danh sách cảnh báo", "Phòng Kinh doanh", "17:00 hôm nay", TaskStatus.DOING, "Cao"),
        WorkItem("Bám đuổi KPI dưới tiến độ ngày đến từng AM", "GĐVTKV / GĐ Cụm KHDN", "18:00 hôm nay", TaskStatus.TODO, "Cao"),
        WorkItem("Cập nhật báo cáo cuối ngày", "Đầu mối báo cáo", "21:00 hôm nay", TaskStatus.TODO, "Trung bình")
    )
}

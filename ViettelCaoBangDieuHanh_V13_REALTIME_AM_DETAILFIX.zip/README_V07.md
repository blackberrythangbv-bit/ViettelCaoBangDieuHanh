# Viettel Cao Bằng Điều Hành v0.7 FULL TRIAL

Bản chạy thử hoàn thiện hơn dựa trên snapshot KPI thực tế ngày 05/09/2026.

- 10 KPI toàn tỉnh
- 6 AM, mỗi AM đủ 10 KPI
- Báo cáo KPI ngày
- Xếp hạng AM theo năng suất bán hàng
- Đánh giá đỏ/vàng/xanh theo tiến độ thời gian tháng (8,3%), không dùng ngưỡng tháng 80/95 cho báo cáo ngày
- Giao việc và deadline
- Donut chart

Lưu ý: dữ liệu vẫn là snapshot ngày 05/09/2026. Bản realtime cần API/nguồn dữ liệu mà app có thể truy cập.

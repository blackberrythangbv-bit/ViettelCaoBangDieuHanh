import os, time, hashlib
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt
from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel
from google.auth import default as google_auth_default
from googleapiclient.discovery import build

APP_VERSION = "0.4.0"
PROGRESS_SHEET_ID = os.environ.get("PROGRESS_SHEET_ID", "")
WEEKLY_SHEET_ID = os.environ.get("WEEKLY_SHEET_ID", "")
ACTIVATION_CODE_SHA256 = os.environ.get("ACTIVATION_CODE_SHA256", "")
JWT_SECRET = os.environ.get("JWT_SECRET", "")
JWT_TTL_DAYS = int(os.environ.get("JWT_TTL_DAYS", "30"))
ALLOWED_DEVICE_IDS = {x.strip() for x in os.environ.get("ALLOWED_DEVICE_IDS", "").split(",") if x.strip()}
CACHE_SECONDS = int(os.environ.get("CACHE_SECONDS", "60"))

app = FastAPI(title="Viettel Cao Bang KPI Private API", version=APP_VERSION, docs_url=None, redoc_url=None)
_cache = {"ts": 0.0, "payload": None}

class ActivationRequest(BaseModel):
    deviceId: str
    activationCode: str


def _require_config():
    missing=[]
    for k,v in {
        "PROGRESS_SHEET_ID": PROGRESS_SHEET_ID,
        "ACTIVATION_CODE_SHA256": ACTIVATION_CODE_SHA256,
        "JWT_SECRET": JWT_SECRET,
    }.items():
        if not v: missing.append(k)
    if missing:
        raise HTTPException(503, f"Server chưa cấu hình: {', '.join(missing)}")


def _hash(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _issue_token(device_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": device_id,
        "aud": "viettel-cao-bang-android",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(days=JWT_TTL_DAYS)).timestamp()),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm="HS256")


def _verify_bearer(authorization: Optional[str]) -> str:
    _require_config()
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Thiếu token")
    token = authorization[7:].strip()
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=["HS256"], audience="viettel-cao-bang-android")
        return str(payload["sub"])
    except Exception:
        raise HTTPException(401, "Token không hợp lệ hoặc đã hết hạn")


def _sheets_service():
    creds, _ = google_auth_default(scopes=["https://www.googleapis.com/auth/spreadsheets.readonly"])
    return build("sheets", "v4", credentials=creds, cache_discovery=False)


def _num(v):
    if v is None or v == "": return 0.0
    if isinstance(v, (int,float)): return float(v)
    s=str(v).strip().replace("%", "")
    # vi_VN: dot thousands, comma decimal
    if "." in s and "," not in s:
        # values like 386.000.000 are integers with thousand separators
        parts=s.split(".")
        if all(len(p)==3 for p in parts[1:]): s="".join(parts)
    s=s.replace(".", "").replace(",", ".") if "," in s else s
    try: return float(s)
    except: return 0.0


def _slug(name: str) -> str:
    table = str.maketrans("áàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ", "aaaaaaaaaaaaaaaaadeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyy")
    return "-".join(name.lower().translate(table).replace("/", " ").split())


def _fetch_progress_payload():
    now=time.time()
    if _cache["payload"] is not None and now-_cache["ts"] < CACHE_SECONDS:
        return _cache["payload"]
    svc=_sheets_service()
    values=svc.spreadsheets().values().get(spreadsheetId=PROGRESS_SHEET_ID, range="Tong_hop!A1:J80").execute().get("values", [])
    report_date = values[2][1] if len(values)>2 and len(values[2])>1 else ""
    items=[]
    # Header row 7 => zero-based row 6; data begins row 8
    for row in values[7:30]:
        if len(row)<2: continue
        if not str(row[0]).strip().isdigit():
            if items: break
            continue
        name=str(row[1]).strip()
        unit=str(row[2]).strip() if len(row)>2 else ""
        plan=_num(row[3] if len(row)>3 else 0)
        actual=_num(row[4] if len(row)>4 else 0)
        items.append({
            "id": _slug(name), "name": name, "plan": plan, "actual": actual,
            "unit": unit, "owner": "Doanh nghiệp số", "asOf": report_date,
        })
    payload={
        "reportDate": report_date,
        "updatedAt": datetime.now().astimezone().strftime("%H:%M"),
        "items": items,
    }
    _cache.update(ts=now, payload=payload)
    return payload


@app.get("/health")
def health():
    return {"status":"ok", "version":APP_VERSION}

@app.post("/api/v1/auth/activate")
def activate(req: ActivationRequest):
    _require_config()
    if ALLOWED_DEVICE_IDS and req.deviceId not in ALLOWED_DEVICE_IDS:
        raise HTTPException(403, "Thiết bị chưa được cấp quyền")
    if _hash(req.activationCode) != ACTIVATION_CODE_SHA256:
        raise HTTPException(403, "Mã kích hoạt không đúng")
    return {"token": _issue_token(req.deviceId), "expiresInDays": JWT_TTL_DAYS}

@app.get("/api/v1/kpi/daily")
def daily(authorization: Optional[str] = Header(default=None)):
    _verify_bearer(authorization)
    return _fetch_progress_payload()

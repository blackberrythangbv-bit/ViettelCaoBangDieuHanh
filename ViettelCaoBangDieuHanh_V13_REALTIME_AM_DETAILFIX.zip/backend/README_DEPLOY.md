# Backend private – Cloud Run

## Kiến trúc
Google Sheets private → Cloud Run → JWT thiết bị → Android.

## Secret/biến môi trường bắt buộc
- `PROGRESS_SHEET_ID`: ID file Theo dõi tiến độ.
- `WEEKLY_SHEET_ID`: ID file Giao chỉ tiêu tuần (dành cho endpoint tuần ở bản sau).
- `ACTIVATION_CODE_SHA256`: SHA-256 của mã kích hoạt nội bộ.
- `JWT_SECRET`: chuỗi ngẫu nhiên >= 32 bytes.
- `JWT_TTL_DAYS`: mặc định 30.
- `ALLOWED_DEVICE_IDS`: tùy chọn, danh sách Android ID cách nhau bằng dấu phẩy.

## Quyền Google Sheet
Chạy Cloud Run bằng một service account riêng. Chia sẻ hai Google Sheets cho email service account với quyền **Viewer**. Bật Google Sheets API trong project GCP.

## Triển khai
Từ thư mục `backend`:

```bash
gcloud run deploy viettel-cbg-kpi-api \
  --source . \
  --region asia-southeast1 \
  --no-allow-unauthenticated \
  --service-account <SERVICE_ACCOUNT_EMAIL>
```

> Với app Android, Cloud Run IAM private trực tiếp sẽ yêu cầu thêm Google identity ở client. Bản pilot này hỗ trợ JWT ứng dụng ở tầng API; khi triển khai thực tế có thể để Cloud Run ingress public HTTPS nhưng **mọi endpoint KPI đều bắt buộc Bearer JWT**, còn `/health` không có dữ liệu. Có thể bổ sung Cloud Armor/API Gateway khi mở rộng.

## Tạo secret
Ví dụ tạo hash mã kích hoạt (không commit mã gốc):

```bash
printf 'MA-KICH-HOAT-NOI-BO' | sha256sum
python -c 'import secrets; print(secrets.token_urlsafe(48))'
```

Sau đó cấu hình các biến/secret trong Cloud Run hoặc Secret Manager.

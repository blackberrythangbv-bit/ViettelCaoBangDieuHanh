package com.viettel.caobang.dieuhanh.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ViettelRed = Color(0xFFD71920)
private val LightScheme = lightColorScheme(
    primary = ViettelRed,
    secondary = Color(0xFF5F6368),
    background = Color(0xFFF7F8FA),
    surface = Color.White
)

@Composable
fun ViettelTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LightScheme, content = content)
}

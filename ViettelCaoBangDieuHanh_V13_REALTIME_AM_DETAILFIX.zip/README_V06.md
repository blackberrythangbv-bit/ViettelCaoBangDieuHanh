# Viettel Cao Bằng Điều hành v0.6 – Báo cáo KPI ngày đến AM

## Nội dung mới
- Mục Báo cáo KPI ngày mở thành báo cáo chi tiết ngay trong app.
- Phần 1: Kết quả 10 KPI toàn tỉnh.
- Phần 2: Tổng hợp đến 6 AM: NUONGPM, LANHT22, HOAIBT4, HUEHT16, THAODP7, QUYENLTN.
- Phần 3: Chọn từng AM để xem đủ 10 KPI KH/TH/%HT.
- Phần 4: Cảnh báo điều hành theo tiến độ thời gian tháng.
- Tiến độ ngày 05/09/2026: 8,3%; còn 22 ngày.

## Nguồn dữ liệu
Snapshot thực tế Google Sheets ngày 05/09/2026. Bản này chưa realtime.

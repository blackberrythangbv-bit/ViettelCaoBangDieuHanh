# V13 REALTIME AM DETAILFIX

- Sửa lỗi người dùng bấm THEO AM nhưng không thấy đủ KPI: chi tiết AM được đưa lên ngay đầu màn hình.
- Mỗi AM hiển thị đủ 10 KPI với KH tuần, TH tuần, %HT tuần, KH tháng, lũy kế tháng, %HT tháng.
- Tăng timeout Google Sheets, retry 2 vòng và có 2 endpoint CSV dự phòng.
- Giữ snapshot chỉ làm phương án dự phòng khi nguồn realtime thực sự không truy cập được.

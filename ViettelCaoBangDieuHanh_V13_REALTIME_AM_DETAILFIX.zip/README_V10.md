# Viettel Cao Bằng Điều Hành – V10 REALTIME FULL

- Phiên bản: 1.0.0-realtime-daily (versionCode 10)
- Realtime Google Sheets cho toàn tỉnh và 6 AM.
- Báo cáo ngày: 10 KPI, tổng hợp AM, xếp hạng AM, cảnh báo.
- Chi tiết từng AM: KH tuần, TH tuần, %HT tuần, KH tháng, lũy kế tháng, %HT KH tháng.
- Chỉ tiêu tuần đọc từ Giao_CT_tuan; TH tuần cộng TH ngày trong tuần hiện hành; tháng đọc từ sheet AM.
- Refresh trực tiếp; fallback snapshot khi mất kết nối.

## Build
Upload ZIP này vào root repo GitHub và thay `.github/workflows/build-apk.yml` bằng `WORKFLOW_BUILD_V10.yml`.
Artifact: `ViettelCaoBangDieuHanh-V10-REALTIME-FULL-APK`.

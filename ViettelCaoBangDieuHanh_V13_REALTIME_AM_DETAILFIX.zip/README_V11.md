# Viettel Cao Bằng Điều Hành V11 REALTIME AM

Khắc phục trực tiếp 2 vấn đề của V10:
1. KPI đến từng AM được đưa ngay vào tab KPI, không còn ẩn trong tab Báo cáo.
2. Bộ đọc Google Sheets không phụ thuộc dòng cố định, tránh lỗi Tong_hop chỉ đọc 8/10 KPI.

Tab KPI có 2 chế độ: TOÀN TỈNH và THEO AM (6).
Trong THEO AM: chọn AM và xem đủ 10 KPI, mỗi KPI hiển thị KH tuần, TH tuần, %HT tuần, KH tháng, lũy kế tháng, %HT tháng.

Realtime đọc Tong_hop + 6 sheet AM + Giao_CT_tuan. Nếu riêng một AM lỗi, chỉ AM đó dùng snapshot; các AM khác vẫn realtime.

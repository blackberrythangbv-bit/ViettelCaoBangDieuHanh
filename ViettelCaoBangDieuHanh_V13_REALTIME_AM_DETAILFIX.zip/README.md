# Điều hành Viettel Cao Bằng – Android v0.3

## Thay đổi v0.3
- KPI chuyển sang biểu đồ donut.
- Xóa MockRepository khỏi luồng KPI.
- KPI chỉ tải qua `SecureKpiRepository` từ API HTTPS riêng tư.
- Không nhúng Google Sheet URL, credential/token hoặc số liệu KPI thật vào APK/source.
- Có trạng thái lỗi an toàn khi API chưa được cấu hình.

## Cấu hình API
Build với Gradle property:

```bash
gradle :app:assembleDebug -PAPI_BASE_URL=https://<private-api-host>
```

Xem `SECURE_API_CONTRACT.md` để biết JSON contract và nguyên tắc bảo mật.

## Lưu ý
Bản source này đã sẵn sàng phía Android. Để app hiển thị KPI thực tế tự động, cần một API/backend private có quyền đọc hai Google Sheets nguồn. Không nên cho APK đọc Google Sheets trực tiếp bằng credential nhúng.

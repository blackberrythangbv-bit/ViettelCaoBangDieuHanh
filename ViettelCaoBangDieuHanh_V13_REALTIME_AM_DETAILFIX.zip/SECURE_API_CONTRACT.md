# Hợp đồng API private – v0.4

1. `POST /api/v1/auth/activate` với `deviceId` + mã kích hoạt nhập thủ công. Backend trả JWT ngắn hạn/dài hạn theo cấu hình.
2. App lưu JWT bằng Android EncryptedSharedPreferences/Keystore.
3. `GET /api/v1/kpi/daily` bắt buộc `Authorization: Bearer <JWT>`.
4. Google credentials, Sheet IDs và secret chỉ nằm ở Cloud Run/Secret Manager. Không commit vào GitHub/APK.

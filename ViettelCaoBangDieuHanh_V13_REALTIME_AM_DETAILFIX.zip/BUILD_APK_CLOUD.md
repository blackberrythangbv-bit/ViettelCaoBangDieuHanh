# Build APK không cần Android Studio

Project đã kèm workflow `.github/workflows/build-apk.yml`.

Khi source được đưa lên GitHub, GitHub Actions sẽ tự động:
1. Cài JDK 17.
2. Cài Android SDK 35.
3. Cài Gradle 8.9.
4. Chạy `:app:assembleDebug`.
5. Xuất artifact `ViettelCaoBangDieuHanh-debug-apk` chứa `app-debug.apk`.

APK debug dùng để cài thử nội bộ. Bản phát hành chính thức cần signing keystore riêng.

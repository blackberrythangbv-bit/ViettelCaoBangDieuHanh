# V12 REALTIME AM INSTALLFIX

Mục tiêu: khắc phục lỗi Android báo "Ứng dụng chưa được cài đặt" sau khi V11 đã gỡ bản cũ.

- applicationId mới: `com.viettel.caobang.dieuhanh.v12` để loại bỏ xung đột package/signature còn sót.
- versionCode 12; versionName 1.2.0-realtime-am-installfix.
- dùng keystore thử nghiệm cố định `app/trial-viettelcb.keystore` để các bản V12.x build sau có thể cập nhật đè nhau.
- giữ chức năng V11: Toàn tỉnh + Theo AM (6), mỗi AM 10 KPI, KH/TH/%HT tuần và KH/TH/%HT tháng.
- bỏ dependency security-crypto không sử dụng để giảm thành phần dư thừa.

Lưu ý: keystore này chỉ dùng cho bản thử nghiệm nội bộ, không dùng làm khóa phát hành production.

# Viettel Cao Bằng Điều hành v0.6 – Báo cáo KPI đến AM

Bản chạy thử dùng snapshot thực tế ngày 05/09/2026.

## Bổ sung v0.6
- Báo cáo KPI ngày trong app theo cấu trúc: toàn tỉnh → tổng hợp AM → chi tiết từng AM → cảnh báo điều hành.
- Dữ liệu 6 AM: NUONGPM, LANHT22, HOAIBT4, HUEHT16, THAODP7, QUYENLTN.
- Mỗi AM có đủ 10 KPI theo sheet riêng.
- Đánh giá tiến độ ngày dựa trên % thời gian tháng đã qua 8,3%, không dùng ngưỡng hoàn thành tháng 80/95% cho phần báo cáo ngày.
- Dữ liệu hiện là snapshot, chưa realtime.

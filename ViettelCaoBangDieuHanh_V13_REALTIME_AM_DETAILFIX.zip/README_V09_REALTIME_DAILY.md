# Viettel Cao Bằng Điều hành v0.9 REALTIME DAILY

Bản v0.9 đưa nội dung chi tiết AM theo đúng cấu trúc báo cáo KPI ngày:
- Chỉ tiêu tuần hiện hành theo `Giao_CT_tuan`.
- KH tuần, TH tuần, %HT tuần.
- KH tháng, TH lũy kế tháng, %HT KH tháng.
- 10 KPI cho từng AM.
- TH tuần được cộng từ cột `TH ngày` trong đúng khoảng tuần hiện hành của sheet AM.
- Chỉ tiêu tuần đọc từ Google Sheet giao chỉ tiêu tuần và forward-fill mã AM.
- Dữ liệu tháng/AM đọc realtime từ Google Sheet theo dõi tiến độ.

Chế độ thử nghiệm đọc Google Sheets trực tiếp; các sheet phải cho phép đọc bằng liên kết.

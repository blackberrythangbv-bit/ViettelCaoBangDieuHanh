# Viettel Cao Bằng Điều hành v0.8 REALTIME TRIAL

- Đọc trực tiếp Google Sheets mỗi lần mở app / bấm Refresh.
- Nguồn tiến độ: sheet `Tong_hop` và 6 sheet AM: `NUONGPM`, `LANHT22`, `HOAIBT4`, `HUEHT16`, `THAODP7`, `QUYENLTN`.
- Không hard-code số liệu làm dữ liệu chính; snapshot 05/09/2026 chỉ là fallback khi mất mạng hoặc Google Sheets không cho đọc.
- Bản trial bỏ qua bảo mật. Để endpoint CSV hoạt động trên Android, Google Sheet cần cho phép đọc không yêu cầu đăng nhập (ví dụ chia sẻ `Anyone with the link - Viewer`).
- Nếu sheet vẫn private, app hiển thị cảnh báo `OFFLINE` và dùng snapshot gần nhất.

## Build
Upload file `ViettelCaoBangDieuHanh_v0.8_REALTIME.zip` vào repo và dùng workflow `WORKFLOW_BUILD_V08.yml`.
Artifact tạo ra: `ViettelCaoBangDieuHanh-v0.8-REALTIME-APK`.

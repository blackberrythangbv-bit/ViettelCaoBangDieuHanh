# Product Spec – Điều hành Viettel Cao Bằng

## Mục tiêu đầu ra
Một màn hình điều hành duy nhất giúp lãnh đạo thấy trong 30 giây:
1. KPI nào đang đỏ/vàng/xanh.
2. Đơn vị/đầu mối nào phải xử lý.
3. Việc nào sắp hoặc đã quá deadline.
4. Báo cáo ngày/tuần có thể phát hành ngay.

## Vai trò dự kiến
- BGĐ: toàn tỉnh, phê duyệt/giao việc.
- Phòng Kinh doanh: tổng hợp, điều hành, cập nhật.
- GĐVTKV: KPI địa bàn, nhận/giao việc.
- GĐ Cụm KHDN: kênh Doanh nghiệp số.
- AM: chỉ tiêu cá nhân, danh sách việc.

## Luồng chính
Dashboard -> KPI cảnh báo -> Drill-down đơn vị -> Giao việc -> Theo dõi deadline -> Báo cáo.

## KPI kiểm soát sản phẩm
- Thời gian mở dashboard mục tiêu: < 2 giây sau khi cache.
- Dữ liệu dashboard: đồng bộ tối đa mỗi 5–15 phút hoặc theo nguồn thực tế.
- 100% việc có owner + deadline + trạng thái.
- 100% KPI cảnh báo có màu và nguyên nhân/đầu mối xử lý ở giai đoạn tích hợp dữ liệu thật.

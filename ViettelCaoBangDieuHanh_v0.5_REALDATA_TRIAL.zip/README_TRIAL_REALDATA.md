# v0.5 Trial – dữ liệu thực

Bản này dùng snapshot KPI thực tế ngày 05/09/2026 từ sheet `Tong_hop` để chạy thử giao diện và luồng điều hành mà chưa cần backend bảo mật.

## KPI thực tế đã nhúng để thử
- Doanh thu truyền thống: KH 386.000.000; TH 8.413.259; 2,2%
- Thâm nhập DN MTL: KH 65; TH 4; 6,2%
- Tổng gia hạn: KH 54; TH 1; 1,9%
- Tendoo: KH 74; TH 0; 0,0%
- MySign: KH 175; TH 13; 7,4%
- Doanh thu dịch vụ mới: KH 18.000.000; TH 0
- M2M/IoT: KH 77; TH 0
- FTTH: KH 6; TH 0
- Doanh thu Giáo dục, Y tế: KH 51.000.000; TH 0
- Năng suất bán hàng: KH 402.000.000; TH 8.413.259; 2,1%

## Lưu ý
Đây là snapshot để kiểm thử UI. Dữ liệu không tự cập nhật sau 05/09/2026. Khi chốt giao diện sẽ thay repository snapshot bằng nguồn realtime.

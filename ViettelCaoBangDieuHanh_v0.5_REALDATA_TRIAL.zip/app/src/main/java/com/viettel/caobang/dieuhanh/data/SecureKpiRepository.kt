package com.viettel.caobang.dieuhanh.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class KpiLoadResult {
    data class Success(val payload: KpiPayload) : KpiLoadResult()
    data class Error(val message: String, val needsActivation: Boolean = false) : KpiLoadResult()
}

/**
 * BẢN CHẠY THỬ v0.5
 * Dữ liệu dưới đây là snapshot thực tế lấy từ sheet Tong_hop ngày 05/09/2026.
 * Mục tiêu: chạy thử giao diện/luồng điều hành trước khi nối API realtime.
 */
object SecureKpiRepository {
    private val snapshot = KpiPayload(
        reportDate = "05/09/2026",
        updatedAt = "Snapshot thực tế 05/09/2026",
        items = listOf(
            KpiItem("dt_truyen_thong", "Doanh thu truyền thống", 386000000.0, 8413259.0, "đồng", "DNS", "05/09/2026"),
            KpiItem("tham_nhap_mtl", "Thâm nhập DN MTL", 65.0, 4.0, "DN", "DNS", "05/09/2026"),
            KpiItem("gia_han", "Tổng gia hạn", 54.0, 1.0, "TB", "DNS", "05/09/2026"),
            KpiItem("tendoo", "Tendoo", 74.0, 0.0, "TB", "DNS", "05/09/2026"),
            KpiItem("mysign", "MySign", 175.0, 13.0, "TB", "DNS", "05/09/2026"),
            KpiItem("dt_dv_moi", "Doanh thu dịch vụ mới", 18000000.0, 0.0, "đồng", "DNS", "05/09/2026"),
            KpiItem("m2m_iot", "M2M/IoT", 77.0, 0.0, "TB", "DNS", "05/09/2026"),
            KpiItem("ftth", "FTTH", 6.0, 0.0, "TB", "DNS", "05/09/2026"),
            KpiItem("dt_gd_yt", "Doanh thu Giáo dục, Y tế", 51000000.0, 0.0, "đồng", "DNS", "05/09/2026"),
            KpiItem("nang_suat_bh", "Năng suất bán hàng", 402000000.0, 8413259.0, "đồng", "DNS", "05/09/2026")
        )
    )

    suspend fun load(context: Context): KpiLoadResult = withContext(Dispatchers.Default) {
        KpiLoadResult.Success(snapshot)
    }

    suspend fun activate(context: Context, code: String): KpiLoadResult = load(context)
}

object TaskRepository {
    val tasks = listOf(
        WorkItem("Rà soát KPI ngày và chốt danh sách cảnh báo", "Phòng Kinh doanh", "17:00 hôm nay", TaskStatus.DOING, "Cao"),
        WorkItem("Bám đuổi KPI dưới ngưỡng", "GĐVTKV / GĐ Cụm KHDN", "18:00 hôm nay", TaskStatus.TODO, "Cao"),
        WorkItem("Cập nhật báo cáo cuối ngày", "Đầu mối báo cáo", "21:00 hôm nay", TaskStatus.TODO, "Trung bình")
    )
}

package com.viettel.caobang.dieuhanh

import android.os.Bundle
import androidx.compose.ui.platform.LocalContext
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.viettel.caobang.dieuhanh.data.*
import com.viettel.caobang.dieuhanh.ui.theme.ViettelTheme
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViettelTheme { ViettelOperationsApp() } }
    }
}

@Composable
fun ViettelOperationsApp() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Điều hành", "KPI", "Công việc", "Báo cáo")
    var payload by remember { mutableStateOf<KpiPayload?>(null) }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    var needsActivation by remember { mutableStateOf(false) }
    var activationCode by remember { mutableStateOf("") }

    LaunchedEffect(refreshKey) {
        loading = true
        when (val result = SecureKpiRepository.load(context)) {
            is KpiLoadResult.Success -> { payload = result.payload; error = null }
            is KpiLoadResult.Error -> { error = result.message; payload = null; needsActivation = result.needsActivation }
        }
        loading = false
    }

    Scaffold(
        topBar = {
            Surface(shadowElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("V", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 28.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ĐIỀU HÀNH VIETTEL CAO BẰNG", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Dashboard tác chiến • v0.5 dữ liệu thực chạy thử", color = Color.Gray, fontSize = 12.sp)
                    }
                    IconButton(onClick = { refreshKey++ }) {
                        Icon(Icons.Default.Refresh, "Làm mới", tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {
                            Icon(
                                when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.DonutLarge; 2 -> Icons.Default.Task; else -> Icons.Default.Description },
                                null
                            )
                        },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        val modifier = Modifier.padding(padding)
        when (tab) {
            0 -> OperationsScreen(modifier, payload, loading, error, onRefresh = { refreshKey++ }, needsActivation, activationCode, { activationCode = it }) { code ->
                loading = true
                when (val r = SecureKpiRepository.activate(context, code)) {
                    is KpiLoadResult.Success -> { payload = r.payload; error = null; needsActivation = false; activationCode = "" }
                    is KpiLoadResult.Error -> { error = r.message; needsActivation = r.needsActivation }
                }
                loading = false
            }
            1 -> KpiScreen(modifier, payload, loading, error, onRefresh = { refreshKey++ }, needsActivation, activationCode, { activationCode = it }) { code ->
                loading = true
                when (val r = SecureKpiRepository.activate(context, code)) {
                    is KpiLoadResult.Success -> { payload = r.payload; error = null; needsActivation = false; activationCode = "" }
                    is KpiLoadResult.Error -> { error = r.message; needsActivation = r.needsActivation }
                }
                loading = false
            }
            2 -> TasksScreen(modifier)
            else -> ReportsScreen(modifier, payload, error)
        }
    }
}

@Composable
fun OperationsScreen(modifier: Modifier, payload: KpiPayload?, loading: Boolean, error: String?, onRefresh: () -> Unit, needsActivation: Boolean, activationCode: String, onCodeChange: (String)->Unit, onActivate: suspend (String)->Unit) {
    val scope = rememberCoroutineScope()
    val kpis = payload?.items.orEmpty()
    val red = kpis.count { it.progress < 80 }
    val yellow = kpis.count { it.progress in 80.0..<95.0 }
    val green = kpis.count { it.progress >= 95 }

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Tổng quan hôm nay", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(payload?.reportDate?.let { "Số liệu ngày $it" } ?: "Snapshot KPI thực tế từ Google Sheets", color = Color.Gray)
        }
        if (loading) item { LoadingCard() }
        if (error != null) item { if (needsActivation) ActivationCard(error, activationCode, onCodeChange) { scope.launch { onActivate(activationCode) } } else SecureConfigCard(error, onRefresh) }
        if (kpis.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatCard("Đỏ", red.toString(), Color(0xFFD32F2F), Modifier.weight(1f))
                    StatCard("Vàng", yellow.toString(), Color(0xFFF9A825), Modifier.weight(1f))
                    StatCard("Xanh", green.toString(), Color(0xFF2E7D32), Modifier.weight(1f))
                }
            }
            item { SectionTitle("Cảnh báo cần bám đuổi") }
            items(kpis.sortedBy { it.progress }.take(3)) { KpiDonutCard(it) }
        }
        item { SectionTitle("Việc trọng tâm") }
        items(TaskRepository.tasks) { TaskRow(it) }
    }
}

@Composable
fun KpiScreen(modifier: Modifier, payload: KpiPayload?, loading: Boolean, error: String?, onRefresh: () -> Unit, needsActivation: Boolean, activationCode: String, onCodeChange: (String)->Unit, onActivate: suspend (String)->Unit) {
    val scope = rememberCoroutineScope()
    val kpis = payload?.items.orEmpty()
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Dashboard KPI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Đỏ <80% • Vàng 80–<95% • Xanh ≥95%", color = Color.Gray, fontSize = 12.sp)
                }
                if (!payload?.updatedAt.isNullOrBlank()) Text(payload!!.updatedAt, fontSize = 10.sp, color = Color.Gray)
            }
        }
        if (loading) item { LoadingCard() }
        if (error != null) item { if (needsActivation) ActivationCard(error, activationCode, onCodeChange) { scope.launch { onActivate(activationCode) } } else SecureConfigCard(error, onRefresh) }
        items(kpis) { KpiDonutCard(it) }
    }
}

@Composable
fun TasksScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Giao việc & Deadline", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Theo dõi đầu mối, trạng thái và việc quá hạn.", color = Color.Gray)
        }
        items(TaskRepository.tasks) { TaskRow(it) }
    }
}

@Composable
fun ReportsScreen(modifier: Modifier, payload: KpiPayload?, error: String?) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Báo cáo nhanh", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(if (payload != null) "Nguồn: snapshot số liệu thực • ${payload.reportDate}" else "Chưa có dữ liệu KPI trực tuyến.", color = Color.Gray)
        if (error != null) Text(error, color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
        ReportCard("Báo cáo KPI ngày", "Tổng hợp tiến độ • cảnh báo • giao việc", Icons.Default.Today)
        ReportCard("Báo cáo KPI tuần", "So sánh kế hoạch tuần và thực hiện", Icons.Default.DateRange)
        ReportCard("Danh sách cảnh báo", "KPI dưới ngưỡng và nhiệm vụ quá hạn", Icons.Default.Warning)
    }
}

@Composable
fun KpiDonutCard(kpi: KpiItem) {
    val p = kpi.progress
    val color = kpiColor(p)
    Card(shape = RoundedCornerShape(18.dp)) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DonutProgress(progress = p, color = color, modifier = Modifier.size(104.dp))
            Spacer(Modifier.width(18.dp))
            Column(Modifier.weight(1f)) {
                Text(kpi.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(4.dp))
                Text(kpi.owner, color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                Text("KH: ${fmt(kpi.plan)} ${kpi.unit}", fontSize = 13.sp)
                Text("TH: ${fmt(kpi.actual)} ${kpi.unit}", fontSize = 13.sp)
                if (kpi.asOf.isNotBlank()) Text("Cập nhật: ${kpi.asOf}", fontSize = 10.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                Surface(color = color.copy(alpha = 0.12f), shape = RoundedCornerShape(50)) {
                    Text(kpiStatus(p), color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                }
            }
        }
    }
}

@Composable
fun DonutProgress(progress: Double, color: Color, modifier: Modifier = Modifier) {
    val safe = progress.coerceIn(0.0, 100.0).toFloat()
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 13.dp.toPx(), cap = StrokeCap.Round)
            val inset = stroke.width / 2f
            val arcSize = Size(size.width - stroke.width, size.height - stroke.width)
            drawArc(
                color = color.copy(alpha = 0.14f), startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = stroke
            )
            drawArc(
                color = color, startAngle = -90f, sweepAngle = 360f * (safe / 100f), useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = stroke
            )
        }
        Text(pct(progress), fontSize = 21.sp, fontWeight = FontWeight.Black, color = color, textAlign = TextAlign.Center)
    }
}

@Composable
fun LoadingCard() {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 3.dp)
            Spacer(Modifier.width(12.dp))
            Text("Đang nạp KPI thực tế…")
        }
    }
}

@Composable
fun ActivationCard(message: String, code: String, onCodeChange: (String)->Unit, onActivate: ()->Unit) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AdminPanelSettings, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp)); Text("Kích hoạt thiết bị", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp)); Text(message, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = code, onValueChange = onCodeChange, label = { Text("Mã kích hoạt nội bộ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = onActivate, enabled = code.isNotBlank()) { Text("Kích hoạt") }
        }
    }
}

@Composable
fun SecureConfigCard(message: String, onRefresh: () -> Unit) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Chế độ dữ liệu riêng tư", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(message, color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = onRefresh) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Thử lại") }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, fontSize = 22.sp, color = accent)
            Text(title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun TaskRow(task: WorkItem) {
    val statusText = when(task.status) { TaskStatus.TODO -> "Chưa làm"; TaskStatus.DOING -> "Đang làm"; TaskStatus.DONE -> "Hoàn thành"; TaskStatus.OVERDUE -> "Quá hạn" }
    val color = when(task.status) { TaskStatus.TODO -> Color.Gray; TaskStatus.DOING -> Color(0xFF1565C0); TaskStatus.DONE -> Color(0xFF2E7D32); TaskStatus.OVERDUE -> Color(0xFFD32F2F) }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(task.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                AssistChip(onClick = {}, label = { Text(statusText, color = color, fontSize = 11.sp) })
            }
            Text("${task.owner} • Deadline: ${task.deadline} • ${task.priority}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable fun SectionTitle(text: String) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

@Composable
fun ReportCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = Color.Gray) }
        }
    }
}

private fun kpiColor(p: Double): Color = when { p < 80 -> Color(0xFFD32F2F); p < 95 -> Color(0xFFF9A825); else -> Color(0xFF2E7D32) }
private fun kpiStatus(p: Double): String = when { p < 80 -> "Dưới ngưỡng"; p < 95 -> "Cảnh báo"; else -> "Đạt tốt" }
private fun fmt(v: Double): String = java.text.NumberFormat.getNumberInstance(java.util.Locale("vi", "VN")).apply { maximumFractionDigits = 1 }.format(v)
private fun pct(v: Double): String = if (v < 10.0 && v != 0.0) String.format(java.util.Locale.US, "%.1f%%", v) else "${v.roundToInt()}%"

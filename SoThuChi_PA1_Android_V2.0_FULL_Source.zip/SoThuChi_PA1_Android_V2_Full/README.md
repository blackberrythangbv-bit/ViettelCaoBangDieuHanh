# Sổ Thu Chi Tự Động V2.0 – PA1 Notification Access

## Chức năng đã có
- Nhận notification Viettel Money qua Android Notification Access; không đọc SMS.
- Parser riêng đúng mẫu Viettel Money: dấu `+/-` là số tiền giao dịch; `Số dư:` chỉ là số dư sau giao dịch.
- Tự xác định THU/CHI, số tiền, số dư, mã giao dịch, nội dung và nhóm chi tiêu.
- Chống ghi trùng bằng mã giao dịch/fingerprint.
- Ngưỡng tự ghi tùy chỉnh 70–100%; giao dịch parser chung chưa đủ chắc chắn đưa vào Chờ xác nhận.
- Dashboard: số dư gần nhất, thu/chi hôm nay, thu/chi tháng, dòng tiền ròng.
- Danh sách giao dịch; thêm thủ công; sửa; xóa.
- Phân loại: Ăn uống, Đi lại, Hóa đơn, Giáo dục, Y tế, Mua sắm, Chuyển khoản, Lương, Hoàn tiền, Lãi/Đầu tư, Thu/Chi khác.
- Xuất CSV có BOM UTF-8 để mở Excel tiếng Việt.
- Lưu SQLite cục bộ. Không khai báo quyền INTERNET. Không gửi giao dịch lên cloud.
- Tùy chọn chỉ nhận Viettel Money hoặc thử parser chung cho ngân hàng/ví khác.

## Cài và sử dụng
1. Mở project bằng Android Studio (JDK 17), Sync Gradle, Build APK.
2. Cài APK lên Android.
3. Mở app > **CẤP / KIỂM TRA QUYỀN ĐỌC THÔNG BÁO** > bật quyền cho **Sổ Thu Chi Tự Động**.
4. Bảo đảm Viettel Money được phép hiện notification biến động số dư.
5. Thực hiện một giao dịch nhỏ để kiểm thử. Notification dạng `-10.000đ / Số dư: ...` sẽ tạo CHI; `+2.000.000đ` sẽ tạo THU.

## Build APK bằng GitHub
Repo đã có `.github/workflows/build-apk.yml`. Upload toàn bộ thư mục lên GitHub > **Actions > Build Android APK > Run workflow**. Sau khi build xong tải artifact `SoThuChi-V2-debug-apk`.

## Quy tắc an toàn dữ liệu
- Không có quyền READ_SMS/RECEIVE_SMS.
- Không có quyền INTERNET.
- Chỉ Android Notification Listener mới đọc notification sau khi người dùng bật quyền hệ thống.
- Dữ liệu tài chính nằm trong SQLite private storage của app; CSV chỉ tạo khi người dùng chủ động xuất.

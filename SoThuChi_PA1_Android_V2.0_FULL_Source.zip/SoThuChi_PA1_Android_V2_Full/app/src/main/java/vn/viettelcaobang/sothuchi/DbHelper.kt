package vn.viettelcaobang.sothuchi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.util.Calendar

class DbHelper(context: Context) : SQLiteOpenHelper(context, "sothuchi.db", null, 2) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE transactions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                amount INTEGER NOT NULL,
                bank TEXT NOT NULL,
                account TEXT NOT NULL DEFAULT '',
                content TEXT NOT NULL,
                category TEXT NOT NULL DEFAULT 'Khác',
                note TEXT NOT NULL DEFAULT '',
                event_time INTEGER NOT NULL,
                balance_after INTEGER,
                transaction_code TEXT NOT NULL DEFAULT '',
                package_name TEXT NOT NULL DEFAULT '',
                raw_text TEXT NOT NULL DEFAULT '',
                fingerprint TEXT NOT NULL UNIQUE,
                confidence INTEGER NOT NULL DEFAULT 100,
                status TEXT NOT NULL DEFAULT 'CONFIRMED',
                source TEXT NOT NULL DEFAULT 'AUTO'
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_tx_time ON transactions(event_time DESC)")
        db.execSQL("CREATE INDEX idx_tx_status ON transactions(status)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            listOf(
                "ALTER TABLE transactions ADD COLUMN category TEXT NOT NULL DEFAULT 'Khác'",
                "ALTER TABLE transactions ADD COLUMN note TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE transactions ADD COLUMN balance_after INTEGER",
                "ALTER TABLE transactions ADD COLUMN transaction_code TEXT NOT NULL DEFAULT ''",
                "ALTER TABLE transactions ADD COLUMN status TEXT NOT NULL DEFAULT 'CONFIRMED'",
                "ALTER TABLE transactions ADD COLUMN source TEXT NOT NULL DEFAULT 'AUTO'"
            ).forEach { sql -> runCatching { db.execSQL(sql) } }
            runCatching { db.execSQL("CREATE INDEX idx_tx_status ON transactions(status)") }
        }
    }

    fun insert(tx: Transaction): Boolean {
        val id = writableDatabase.insertWithOnConflict("transactions", null, values(tx), SQLiteDatabase.CONFLICT_IGNORE)
        return id != -1L
    }

    fun update(tx: Transaction): Boolean = writableDatabase.update("transactions", values(tx), "id=?", arrayOf(tx.id.toString())) > 0

    fun delete(id: Long): Boolean = writableDatabase.delete("transactions", "id=?", arrayOf(id.toString())) > 0

    fun confirm(id: Long): Boolean {
        val v = ContentValues().apply { put("status", Transaction.STATUS_CONFIRMED); put("confidence", 100) }
        return writableDatabase.update("transactions", v, "id=?", arrayOf(id.toString())) > 0
    }

    fun recent(limit: Int = 200, type: String? = null, status: String? = Transaction.STATUS_CONFIRMED, query: String = ""): List<Transaction> {
        val clauses = mutableListOf<String>(); val args = mutableListOf<String>()
        if (!type.isNullOrBlank() && type != "TẤT CẢ") { clauses += "type=?"; args += type }
        if (!status.isNullOrBlank()) { clauses += "status=?"; args += status }
        if (query.isNotBlank()) { clauses += "(content LIKE ? OR category LIKE ? OR bank LIKE ? OR CAST(amount AS TEXT) LIKE ?)"; repeat(4) { args += "%$query%" } }
        val where = if (clauses.isEmpty()) "" else "WHERE " + clauses.joinToString(" AND ")
        val out = mutableListOf<Transaction>()
        readableDatabase.rawQuery("SELECT * FROM transactions $where ORDER BY event_time DESC LIMIT ?", (args + limit.toString()).toTypedArray()).use { c ->
            while (c.moveToNext()) out += fromCursor(c)
        }
        return out
    }

    fun get(id: Long): Transaction? {
        readableDatabase.rawQuery("SELECT * FROM transactions WHERE id=?", arrayOf(id.toString())).use { c -> if (c.moveToFirst()) return fromCursor(c) }
        return null
    }

    fun pendingCount(): Int {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM transactions WHERE status=?", arrayOf(Transaction.STATUS_REVIEW)).use { c -> return if (c.moveToFirst()) c.getInt(0) else 0 }
    }

    fun latestBalance(): Long? {
        readableDatabase.rawQuery("SELECT balance_after FROM transactions WHERE balance_after IS NOT NULL AND status=? ORDER BY event_time DESC LIMIT 1", arrayOf(Transaction.STATUS_CONFIRMED)).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
        }
        return null
    }

    fun totals(from: Long, to: Long = Long.MAX_VALUE): Pair<Long, Long> {
        var income = 0L; var expense = 0L
        readableDatabase.rawQuery("SELECT type, COALESCE(SUM(amount),0) FROM transactions WHERE status=? AND event_time>=? AND event_time<? GROUP BY type", arrayOf(Transaction.STATUS_CONFIRMED, from.toString(), to.toString())).use { c ->
            while (c.moveToNext()) if (c.getString(0) == "THU") income = c.getLong(1) else if (c.getString(0) == "CHI") expense = c.getLong(1)
        }
        return income to expense
    }

    fun monthTotals(): Pair<Long, Long> = totals(startOfMonth())
    fun todayTotals(): Pair<Long, Long> = totals(startOfToday())

    fun allConfirmed(): List<Transaction> = recent(limit = 10000, status = Transaction.STATUS_CONFIRMED)

    private fun values(tx: Transaction) = ContentValues().apply {
        put("type", tx.type); put("amount", tx.amount); put("bank", tx.bank); put("account", tx.account)
        put("content", tx.content); put("category", tx.category); put("note", tx.note); put("event_time", tx.eventTime)
        if (tx.balanceAfter == null) putNull("balance_after") else put("balance_after", tx.balanceAfter)
        put("transaction_code", tx.transactionCode); put("package_name", tx.packageName); put("raw_text", tx.rawText)
        put("fingerprint", tx.fingerprint); put("confidence", tx.confidence); put("status", tx.status); put("source", tx.source)
    }

    private fun fromCursor(c: android.database.Cursor) = Transaction(
        id = c.getLong(c.getColumnIndexOrThrow("id")),
        type = c.getString(c.getColumnIndexOrThrow("type")),
        amount = c.getLong(c.getColumnIndexOrThrow("amount")),
        bank = c.getString(c.getColumnIndexOrThrow("bank")),
        account = c.getString(c.getColumnIndexOrThrow("account")),
        content = c.getString(c.getColumnIndexOrThrow("content")),
        category = c.getString(c.getColumnIndexOrThrow("category")),
        note = c.getString(c.getColumnIndexOrThrow("note")),
        eventTime = c.getLong(c.getColumnIndexOrThrow("event_time")),
        balanceAfter = c.getColumnIndex("balance_after").let { if (it >= 0 && !c.isNull(it)) c.getLong(it) else null },
        transactionCode = c.getString(c.getColumnIndexOrThrow("transaction_code")),
        packageName = c.getString(c.getColumnIndexOrThrow("package_name")),
        rawText = c.getString(c.getColumnIndexOrThrow("raw_text")),
        fingerprint = c.getString(c.getColumnIndexOrThrow("fingerprint")),
        confidence = c.getInt(c.getColumnIndexOrThrow("confidence")),
        status = c.getString(c.getColumnIndexOrThrow("status")),
        source = c.getString(c.getColumnIndexOrThrow("source"))
    )

    private fun startOfToday(): Long = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
    private fun startOfMonth(): Long = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH,1); set(Calendar.HOUR_OF_DAY,0); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }.timeInMillis
}

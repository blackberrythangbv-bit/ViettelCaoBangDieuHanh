package vn.viettelcaobang.sothuchi

import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import vn.viettelcaobang.sothuchi.databinding.ActivityMainBinding
import java.io.OutputStreamWriter
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private lateinit var db: DbHelper
    private lateinit var settingsStore: SettingsStore
    private val money = NumberFormat.getNumberInstance(Locale("vi", "VN"))
    private val dt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("vi", "VN"))
    private var screen = "DASHBOARD"

    private val exportCsv = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) runCatching {
            contentResolver.openOutputStream(uri)?.use { os ->
                OutputStreamWriter(os, Charsets.UTF_8).use { w ->
                    w.write("\uFEFFNgày,Loại,Số tiền,Nhóm,Nguồn,Nội dung,Số dư sau GD,Mã GD,Ghi chú\n")
                    db.allConfirmed().reversed().forEach { t ->
                        val row = listOf(dt.format(Date(t.eventTime)), t.type, t.amount.toString(), t.category, t.bank, t.content, t.balanceAfter?.toString().orEmpty(), t.transactionCode, t.note)
                            .joinToString(",") { csv(it) }
                        w.write(row + "\n")
                    }
                }
            }
        }.onSuccess { toast("Đã xuất CSV") }.onFailure { toast("Không xuất được file: ${it.message}") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        db = DbHelper(this); settingsStore = SettingsStore(this)

        b.btnDashboard.setOnClickListener { showScreen("DASHBOARD") }
        b.btnTransactions.setOnClickListener { showScreen("TRANSACTIONS") }
        b.btnReview.setOnClickListener { showScreen("REVIEW") }
        b.btnSettings.setOnClickListener { showScreen("SETTINGS") }
        b.btnAdd.setOnClickListener { editDialog(null) }
        b.btnNotificationAccess.setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        b.btnExport.setOnClickListener { exportCsv.launch("SoThuChi_${SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())}.csv") }
        b.cbViettelMoney.setOnCheckedChangeListener { _, checked -> settingsStore.viettelMoneyEnabled = checked }
        b.cbOtherBanks.setOnCheckedChangeListener { _, checked -> settingsStore.otherBanksEnabled = checked }
        b.seekThreshold.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { val v = (70 + progress).coerceAtMost(100); b.tvThreshold.text = "Ngưỡng tự ghi: $v%"; if (fromUser) settingsStore.autoSaveThreshold = v }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        showScreen("DASHBOARD")
    }

    override fun onResume() { super.onResume(); render() }

    private fun showScreen(s: String) { screen = s; render() }

    private fun render() {
        val panels = listOf(b.panelDashboard, b.panelTransactions, b.panelReview, b.panelSettings)
        panels.forEach { it.visibility = View.GONE }
        when (screen) {
            "TRANSACTIONS" -> { b.panelTransactions.visibility = View.VISIBLE; renderTransactions() }
            "REVIEW" -> { b.panelReview.visibility = View.VISIBLE; renderReview() }
            "SETTINGS" -> { b.panelSettings.visibility = View.VISIBLE; renderSettings() }
            else -> { b.panelDashboard.visibility = View.VISIBLE; renderDashboard() }
        }
        b.tvReviewBadge.text = db.pendingCount().toString()
    }

    private fun renderDashboard() {
        val (ti, te) = db.todayTotals(); val (mi, me) = db.monthTotals(); val bal = db.latestBalance()
        b.tvBalance.text = if (bal == null) "Chưa có dữ liệu" else "${money.format(bal)} đ"
        b.tvToday.text = "Hôm nay: +${money.format(ti)} / -${money.format(te)} đ"
        b.tvMonthIncome.text = "Thu tháng: ${money.format(mi)} đ"
        b.tvMonthExpense.text = "Chi tháng: ${money.format(me)} đ"
        b.tvMonthNet.text = "Dòng tiền ròng: ${money.format(mi - me)} đ"
        b.tvAccessStatus.text = if (hasNotificationAccess()) "Notification Access: ĐÃ BẬT" else "Notification Access: CHƯA BẬT"
        renderList(b.listRecent, db.recent(10), false)
    }

    private fun renderTransactions() {
        val items = db.recent(300, status = Transaction.STATUS_CONFIRMED)
        renderList(b.listAll, items, true)
        b.tvTransactionCount.text = "${items.size} giao dịch gần nhất"
    }

    private fun renderReview() {
        val items = db.recent(300, status = Transaction.STATUS_REVIEW)
        b.tvReviewEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        renderList(b.listReview, items, true, reviewMode = true)
    }

    private fun renderSettings() {
        b.cbViettelMoney.setOnCheckedChangeListener(null); b.cbOtherBanks.setOnCheckedChangeListener(null)
        b.cbViettelMoney.isChecked = settingsStore.viettelMoneyEnabled; b.cbOtherBanks.isChecked = settingsStore.otherBanksEnabled
        b.cbViettelMoney.setOnCheckedChangeListener { _, checked -> settingsStore.viettelMoneyEnabled = checked }
        b.cbOtherBanks.setOnCheckedChangeListener { _, checked -> settingsStore.otherBanksEnabled = checked }
        b.seekThreshold.progress = settingsStore.autoSaveThreshold - 70
        b.tvThreshold.text = "Ngưỡng tự ghi: ${settingsStore.autoSaveThreshold}%"
        b.tvPrivacy.text = "Dữ liệu đang lưu cục bộ trên điện thoại. App không khai báo quyền Internet và không đọc SMS."
    }

    private fun renderList(container: LinearLayout, items: List<Transaction>, editable: Boolean, reviewMode: Boolean = false) {
        container.removeAllViews()
        items.forEach { t ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22,18,22,18); setBackgroundResource(R.drawable.card_bg) }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT); lp.setMargins(0,0,0,12); card.layoutParams = lp
            card.addView(TextView(this).apply { text = "${if (t.type == "THU") "+" else "−"}${money.format(t.amount)} đ · ${t.category}"; textSize = 18f; setTypeface(typeface, Typeface.BOLD) })
            card.addView(TextView(this).apply { text = "${t.bank} · ${dt.format(Date(t.eventTime))}"; textSize = 13f })
            card.addView(TextView(this).apply { text = t.content; textSize = 14f; maxLines = 3 })
            t.balanceAfter?.let { card.addView(TextView(this).apply { text = "Số dư sau GD: ${money.format(it)} đ"; textSize = 13f }) }
            if (reviewMode) {
                card.addView(TextView(this).apply { text = "Cần xác nhận · độ tin cậy ${t.confidence}%"; textSize = 12f })
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(Button(this).apply { text = "XÁC NHẬN"; setOnClickListener { db.confirm(t.id); render() } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                row.addView(Button(this).apply { text = "XÓA"; setOnClickListener { confirmDelete(t) } }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                card.addView(row)
            } else if (editable) card.setOnClickListener { editDialog(t) }
            container.addView(card)
        }
    }

    private fun editDialog(existing: Transaction?) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 10, 36, 0) }
        val type = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, listOf("CHI","THU")); setSelection(if (existing?.type == "THU") 1 else 0) }
        val amount = EditText(this).apply { hint = "Số tiền"; inputType = InputType.TYPE_CLASS_NUMBER; existing?.let { setText(it.amount.toString()) } }
        val content = EditText(this).apply { hint = "Nội dung"; setText(existing?.content.orEmpty()) }
        val category = Spinner(this).apply { val cats = listOf("Ăn uống","Đi lại","Hóa đơn","Giáo dục","Y tế","Mua sắm","Chuyển khoản","Chi khác","Lương","Hoàn tiền","Lãi/Đầu tư","Thu khác"); adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, cats); val idx = cats.indexOf(existing?.category); if (idx >= 0) setSelection(idx) }
        val note = EditText(this).apply { hint = "Ghi chú"; setText(existing?.note.orEmpty()) }
        listOf(type, amount, category, content, note).forEach { wrap.addView(it) }
        AlertDialog.Builder(this).setTitle(if (existing == null) "Thêm giao dịch" else "Sửa giao dịch").setView(wrap)
            .setPositiveButton("LƯU") { _, _ ->
                val a = amount.text.toString().toLongOrNull(); if (a == null || a <= 0) { toast("Số tiền không hợp lệ"); return@setPositiveButton }
                val now = existing?.eventTime ?: System.currentTimeMillis(); val c = content.text.toString().ifBlank { "Giao dịch thủ công" }
                val fp = existing?.fingerprint ?: sha256("MANUAL|$now|$a|${type.selectedItem}|$c")
                val tx = Transaction(id = existing?.id ?: 0, type = type.selectedItem.toString(), amount = a, bank = existing?.bank ?: "Thủ công", account = existing?.account.orEmpty(), content = c, category = category.selectedItem.toString(), note = note.text.toString(), eventTime = now, balanceAfter = existing?.balanceAfter, transactionCode = existing?.transactionCode.orEmpty(), packageName = existing?.packageName.orEmpty(), rawText = existing?.rawText.orEmpty(), fingerprint = fp, confidence = 100, status = Transaction.STATUS_CONFIRMED, source = existing?.source ?: Transaction.SOURCE_MANUAL)
                if (existing == null) db.insert(tx) else db.update(tx); render()
            }
            .setNegativeButton("HỦY", null)
            .apply { if (existing != null) setNeutralButton("XÓA") { _, _ -> confirmDelete(existing) } }
            .show()
    }

    private fun confirmDelete(t: Transaction) { AlertDialog.Builder(this).setTitle("Xóa giao dịch?").setMessage("${money.format(t.amount)} đ · ${t.content}").setPositiveButton("XÓA") { _, _ -> db.delete(t.id); render() }.setNegativeButton("HỦY", null).show() }

    private fun hasNotificationAccess(): Boolean {
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(":").mapNotNull { ComponentName.unflattenFromString(it) }.any { it.packageName == packageName }
    }

    private fun csv(s: String): String = "\"${s.replace("\"", "\"\"")}\""
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

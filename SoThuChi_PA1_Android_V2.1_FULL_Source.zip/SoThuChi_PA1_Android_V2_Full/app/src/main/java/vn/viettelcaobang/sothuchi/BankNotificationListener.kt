package vn.viettelcaobang.sothuchi

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class BankNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (sbn.packageName == packageName) return
        val settings = SettingsStore(applicationContext)
        val allowed = when (sbn.packageName) {
            BankParser.VIETTEL_MONEY_PACKAGE -> settings.viettelMoneyEnabled
            else -> settings.otherBanksEnabled
        }
        if (!allowed) return

        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val textParts = listOfNotNull(
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" ")
        ).filter { it.isNotBlank() }.distinct()
        val text = textParts.joinToString(" | ")
        val parsed = BankParser.parse(sbn.packageName, title, text, sbn.postTime) ?: return
        val status = if (parsed.confidence >= settings.autoSaveThreshold) Transaction.STATUS_CONFIRMED else Transaction.STATUS_REVIEW
        DbHelper(applicationContext).insert(parsed.copy(status = status))
    }
}

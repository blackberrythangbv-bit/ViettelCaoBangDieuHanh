package vn.viettelcaobang.sothuchi

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class ExpenseChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    private var data: List<Pair<String, Long>> = emptyList()
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(229, 5, 0) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.DKGRAY; textSize = 28f; textAlign = Paint.Align.CENTER }
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.LTGRAY; strokeWidth = 2f }

    fun setData(items: List<Pair<String, Long>>) {
        data = items
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) {
            canvas.drawText("Chưa có dữ liệu", width / 2f, height / 2f, textPaint)
            return
        }
        val left = 20f
        val right = width - 20f
        val top = 20f
        val bottom = height - 46f
        canvas.drawLine(left, bottom, right, bottom, axisPaint)
        val maxValue = max(1L, data.maxOf { it.second })
        val slot = (right - left) / data.size
        val barW = slot * 0.58f
        data.forEachIndexed { i, (label, value) ->
            val x = left + slot * i + slot / 2f
            val h = (bottom - top) * (value.toFloat() / maxValue.toFloat())
            canvas.drawRect(x - barW / 2f, bottom - h, x + barW / 2f, bottom, barPaint)
            canvas.drawText(label, x, height - 12f, textPaint)
        }
    }
}

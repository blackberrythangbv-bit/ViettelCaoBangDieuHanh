package vn.viettelcaobang.sothuchi

import java.security.MessageDigest
import java.text.Normalizer
import java.util.Locale

object BankParser {
    const val VIETTEL_MONEY_PACKAGE = "com.bplus.vtpay"

    private val knownPackages = mapOf(
        VIETTEL_MONEY_PACKAGE to "Viettel Money",
        "com.mbmobile" to "MB",
        "com.bidv.smartbanking" to "BIDV",
        "com.vnpay.vietinbank" to "VietinBank",
        "vn.com.techcombank.bb.app" to "Techcombank",
        "com.vib.myvib2" to "VIB",
        "com.tpb.mb.gprsandroid" to "TPBank",
        "com.mservice.momotransfer" to "MoMo"
    )

    fun parse(packageName: String, title: String, text: String, eventTime: Long): Transaction? {
        if (packageName == VIETTEL_MONEY_PACKAGE) {
            return parseViettelMoney(packageName, title, text, eventTime)
        }
        return parseGeneric(packageName, title, text, eventTime)
    }

    private fun parseViettelMoney(pkg: String, title: String, text: String, eventTime: Long): Transaction? {
        val raw = listOf(title, text).filter { it.isNotBlank() }.joinToString(" | ")
        if (raw.isBlank()) return null
        val signed = Regex("([+-])\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*(?:đ|d|vnd|vnđ)", RegexOption.IGNORE_CASE)
            .find(title.ifBlank { raw }) ?: return null
        val sign = signed.groupValues[1]
        val amount = moneyToLong(signed.groupValues[2]) ?: return null
        if (amount <= 0) return null
        val type = if (sign == "+") "THU" else "CHI"

        val balance = Regex("(?i)s[oố]\\s*d[uư]\\s*[:]?\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*(?:đ|d)?")
            .find(raw)?.groupValues?.getOrNull(1)?.let(::moneyToLong)

        val cleaned = raw.replace(Regex("(?i)s[oố]\\s*d[uư]\\s*[:]?\\s*[\\d.,]+\\s*(?:đ|d)?"), "")
            .replace(Regex("\\s*\\|\\s*"), " ")
            .replace(Regex("\\s+"), " ").trim()

        val txCode = Regex("\\b\\d{12,20}\\b").find(cleaned)?.value.orEmpty()
        val category = autoCategory(cleaned, type)
        val confidence = 100
        val fpBase = if (txCode.isNotBlank()) "VTM|$txCode|$type|$amount" else "VTM|$type|$amount|${balance ?: 0}|${eventTime / 60000}|${normalize(cleaned).take(100)}"
        return Transaction(
            type = type,
            amount = amount,
            bank = "Viettel Money",
            content = cleaned.ifBlank { if (type == "THU") "Tiền vào Viettel Money" else "Tiền ra Viettel Money" },
            category = category,
            eventTime = eventTime,
            balanceAfter = balance,
            transactionCode = txCode,
            packageName = pkg,
            rawText = raw,
            fingerprint = sha256(fpBase),
            confidence = confidence,
            status = Transaction.STATUS_CONFIRMED,
            source = Transaction.SOURCE_AUTO
        )
    }

    private fun parseGeneric(pkg: String, title: String, text: String, eventTime: Long): Transaction? {
        val raw = listOf(title, text).filter { it.isNotBlank() }.joinToString(" | ")
        val n = normalize(raw)
        if (raw.length < 5 || listOf("otp", "ma xac thuc", "verification code").any { it in n }) return null
        val bank = knownPackages[pkg] ?: detectBank(n) ?: return null
        val signed = Regex("([+-])\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*(?:vnd|vnđ|đ|d)", RegexOption.IGNORE_CASE).find(raw)
        val amountMatch = signed ?: Regex("(?i)(?:so tien|s[oố] ti[eề]n|amount)\\s*[:]?\\s*(\\d{1,3}(?:[.,]\\d{3})+|\\d+)\\s*(?:vnd|vnđ|đ|d)?").find(raw)
        val amountText = if (signed != null) signed.groupValues[2] else amountMatch?.groupValues?.getOrNull(1)
        val amount = amountText?.let(::moneyToLong) ?: return null
        val type = when {
            signed?.groupValues?.get(1) == "+" -> "THU"
            signed?.groupValues?.get(1) == "-" -> "CHI"
            listOf("ghi co", "nhan tien", "cong tien", "credit").any { it in n } -> "THU"
            listOf("ghi no", "tru tien", "thanh toan", "chuyen tien", "debit").any { it in n } -> "CHI"
            else -> return null
        }
        val account = Regex("(?i)(?:tk|tai khoan|t[aà]i kho[aả]n|account)\\s*[:.]?\\s*([*xX\\d]{4,20})").find(raw)?.groupValues?.getOrNull(1).orEmpty()
        val confidence = (65 + (if (knownPackages.containsKey(pkg)) 15 else 0) + (if (signed != null) 15 else 0) + (if (account.isNotBlank()) 5 else 0)).coerceAtMost(95)
        val fp = sha256("$bank|$account|$type|$amount|${eventTime / 60000}|${n.take(140)}")
        return Transaction(type = type, amount = amount, bank = bank, account = account, content = raw.take(300), category = autoCategory(raw, type), eventTime = eventTime, packageName = pkg, rawText = raw, fingerprint = fp, confidence = confidence, status = Transaction.STATUS_REVIEW, source = Transaction.SOURCE_AUTO)
    }

    fun autoCategory(content: String, type: String): String {
        val n = normalize(content)
        if (type == "THU") {
            return when {
                listOf("luong", "salary").any { it in n } -> "Lương"
                listOf("hoan tien", "refund").any { it in n } -> "Hoàn tiền"
                listOf("lai", "interest").any { it in n } -> "Lãi/Đầu tư"
                else -> "Thu khác"
            }
        }
        return when {
            listOf("an sang", "an trua", "an toi", "cafe", "coffee", "nha hang", "quan an").any { it in n } -> "Ăn uống"
            listOf("xang", "petrol", "grab", "taxi", "be ").any { it in n } -> "Đi lại"
            listOf("dien", "nuoc", "internet", "viettel", "mobile", "dien thoai").any { it in n } -> "Hóa đơn"
            listOf("hoc phi", "school", "giao duc").any { it in n } -> "Giáo dục"
            listOf("benh vien", "thuoc", "pharmacy", "y te").any { it in n } -> "Y tế"
            listOf("shopee", "lazada", "tiki", "mua sam").any { it in n } -> "Mua sắm"
            listOf("chuyen tien", "gd chuyen tien").any { it in n } -> "Chuyển khoản"
            else -> "Chi khác"
        }
    }

    private fun detectBank(n: String): String? = when {
        "vietcombank" in n || "vcb" in n -> "Vietcombank"
        "vietinbank" in n || "ctg" in n -> "VietinBank"
        "bidv" in n -> "BIDV"
        "techcombank" in n || "tcb" in n -> "Techcombank"
        "mbbank" in n || Regex("\\bmb\\b").containsMatchIn(n) -> "MB"
        "tpbank" in n -> "TPBank"
        "vib" in n -> "VIB"
        "agribank" in n -> "Agribank"
        else -> null
    }

    private fun moneyToLong(s: String): Long? = s.replace(".", "").replace(",", "").trim().toLongOrNull()

    private fun normalize(s: String): String {
        val x = Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        return x.replace(Regex("\\p{Mn}+"), "").replace('đ', 'd')
    }

    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}

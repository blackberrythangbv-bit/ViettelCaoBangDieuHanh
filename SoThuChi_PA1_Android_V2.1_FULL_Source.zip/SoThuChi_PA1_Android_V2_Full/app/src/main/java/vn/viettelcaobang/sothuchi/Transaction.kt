package vn.viettelcaobang.sothuchi

data class Transaction(
    val id: Long = 0,
    val type: String,
    val amount: Long,
    val bank: String,
    val account: String = "",
    val content: String,
    val category: String = "Khác",
    val note: String = "",
    val eventTime: Long,
    val balanceAfter: Long? = null,
    val transactionCode: String = "",
    val packageName: String = "",
    val rawText: String = "",
    val fingerprint: String,
    val confidence: Int = 100,
    val status: String = STATUS_CONFIRMED,
    val source: String = SOURCE_AUTO
) {
    companion object {
        const val STATUS_CONFIRMED = "CONFIRMED"
        const val STATUS_REVIEW = "REVIEW"
        const val SOURCE_AUTO = "AUTO"
        const val SOURCE_MANUAL = "MANUAL"
    }
}

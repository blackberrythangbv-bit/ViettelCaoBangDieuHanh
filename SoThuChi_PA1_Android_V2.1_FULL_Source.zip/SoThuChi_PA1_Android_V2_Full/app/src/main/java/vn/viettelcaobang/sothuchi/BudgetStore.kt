package vn.viettelcaobang.sothuchi

import android.content.Context
import org.json.JSONObject

class BudgetStore(context: Context) {
    private val p = context.getSharedPreferences("budget_settings", Context.MODE_PRIVATE)

    var monthlyBudget: Long
        get() = p.getLong("monthly_total", 0L)
        set(v) = p.edit().putLong("monthly_total", v.coerceAtLeast(0L)).apply()

    fun categoryBudget(category: String): Long = p.getLong("cat_${key(category)}", 0L)

    fun setCategoryBudget(category: String, amount: Long) {
        p.edit().putLong("cat_${key(category)}", amount.coerceAtLeast(0L)).apply()
    }

    fun toJson(categories: List<String>): JSONObject = JSONObject().apply {
        put("monthlyBudget", monthlyBudget)
        val cats = JSONObject()
        categories.forEach { cats.put(it, categoryBudget(it)) }
        put("categories", cats)
    }

    fun restore(json: JSONObject, categories: List<String>) {
        monthlyBudget = json.optLong("monthlyBudget", 0L)
        val cats = json.optJSONObject("categories") ?: JSONObject()
        categories.forEach { setCategoryBudget(it, cats.optLong(it, 0L)) }
    }

    private fun key(s: String): String = s.lowercase()
        .replace("đ", "d")
        .replace(Regex("[^a-z0-9]+"), "_")
        .trim('_')
}

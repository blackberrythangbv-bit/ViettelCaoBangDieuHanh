package vn.viettelcaobang.sothuchi

import android.content.Context

class SettingsStore(context: Context) {
    private val p = context.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    var viettelMoneyEnabled: Boolean
        get() = p.getBoolean("viettel_money", true)
        set(v) = p.edit().putBoolean("viettel_money", v).apply()

    var otherBanksEnabled: Boolean
        get() = p.getBoolean("other_banks", false)
        set(v) = p.edit().putBoolean("other_banks", v).apply()

    var autoSaveThreshold: Int
        get() = p.getInt("auto_threshold", 90)
        set(v) = p.edit().putInt("auto_threshold", v.coerceIn(70, 100)).apply()
}

# Sổ Thu Chi Tự Động V2.1

Bản V2.1 bổ sung trên V2.0:
- Dashboard số dư, thu/chi ngày-tháng, dòng tiền ròng.
- Biểu đồ chi 7 ngày gần nhất.
- Ngân sách tháng và hạn mức theo 8 nhóm chi; cảnh báo vượt ngân sách.
- Tìm kiếm giao dịch.
- Sao lưu toàn bộ giao dịch + cài đặt + ngân sách ra JSON.
- Khôi phục toàn bộ dữ liệu từ JSON.
- Giữ nguyên Notification Access Viettel Money, parser Thu/Chi, chống trùng, chờ xác nhận, nhập/sửa/xóa thủ công, xuất CSV.

## Build APK
Upload toàn bộ thư mục lên GitHub -> Actions -> Build Android APK -> Run workflow.
Artifact: `SoThuChi-V2.1-debug-apk`.

## Bảo mật
Không khai báo INTERNET, không đọc SMS. Dữ liệu mặc định nằm cục bộ trên điện thoại. File backup JSON do người dùng chủ động lưu ra vị trí đã chọn.

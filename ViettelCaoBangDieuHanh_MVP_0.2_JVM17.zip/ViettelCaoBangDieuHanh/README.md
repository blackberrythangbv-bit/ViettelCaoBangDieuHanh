# Điều hành Viettel Cao Bằng – Android MVP

Ứng dụng Android native (Kotlin + Jetpack Compose) phục vụ điều hành tác chiến.

## MVP hiện có
- Dashboard tổng quan theo ngưỡng Đỏ / Vàng / Xanh.
- KPI: FTTH, Di động, Doanh nghiệp số, Tendoo, Năng suất bán hàng.
- Giao việc: đầu mối, deadline, trạng thái, cảnh báo quá hạn.
- Màn hình báo cáo nhanh KPI ngày / tuần.
- Dữ liệu mẫu tách riêng trong `MockRepository.kt`, thuận tiện thay bằng API/Google Sheets.

## Ngưỡng cảnh báo mặc định
- Đỏ: < 80%
- Vàng: 80% đến < 95%
- Xanh: >= 95%

## Mở dự án
1. Cài Android Studio (JDK 17+).
2. Open thư mục `ViettelCaoBangDieuHanh`.
3. Cho Android Studio đồng bộ Gradle.
4. Run trên máy Android hoặc emulator (Android 8.0+).

## Kiến trúc nâng cấp đề xuất
Giai đoạn 2:
- Kết nối Google Sheets "Theo dõi tiến độ" và "Giao chỉ tiêu tuần" qua backend/API an toàn.
- Đăng nhập theo vai trò: BGĐ / Phòng KD / GĐVTKV / GĐ Cụm KHDN / AM.
- Push notification cho KPI dưới ngưỡng và deadline.
- Drill-down KPI đến khu vực/AM.
- Báo cáo ngày/tuần xuất PDF/Excel.

Giai đoạn 3:
- Firebase/FCM hoặc backend Viettel nội bộ.
- Audit log giao việc, xác nhận hoàn thành, bằng chứng ảnh/tệp.
- Dashboard xu hướng D-1, tuần, tháng.

## Lưu ý bảo mật
Không nên nhúng trực tiếp credential Google hoặc token API trong APK. Dữ liệu thật nên đi qua backend hoặc cơ chế OAuth/API Gateway được kiểm soát.

package com.viettel.caobang.dieuhanh.data

data class KpiItem(
    val name: String,
    val plan: Double,
    val actual: Double,
    val unit: String,
    val owner: String
) {
    val progress: Double get() = if (plan == 0.0) 0.0 else actual / plan * 100.0
}

enum class TaskStatus { TODO, DOING, DONE, OVERDUE }

data class WorkItem(
    val title: String,
    val owner: String,
    val deadline: String,
    val status: TaskStatus,
    val priority: String
)

package com.viettel.caobang.dieuhanh

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.viettel.caobang.dieuhanh.data.*
import com.viettel.caobang.dieuhanh.ui.theme.ViettelTheme
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ViettelTheme { ViettelOperationsApp() } }
    }
}

@Composable
fun ViettelOperationsApp() {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Điều hành", "KPI", "Công việc", "Báo cáo")

    Scaffold(
        topBar = {
            Surface(shadowElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(38.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("V", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Black, fontSize = 28.sp) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("ĐIỀU HÀNH VIETTEL CAO BẰNG", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Dashboard tác chiến • MVP 0.1", color = Color.Gray, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.Notifications, null, tint = MaterialTheme.colorScheme.primary)
                }
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = {
                            Icon(
                                when(index) { 0 -> Icons.Default.Home; 1 -> Icons.Default.ShowChart; 2 -> Icons.Default.Task; else -> Icons.Default.Description },
                                null
                            )
                        },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        when (tab) {
            0 -> OperationsScreen(Modifier.padding(padding))
            1 -> KpiScreen(Modifier.padding(padding))
            2 -> TasksScreen(Modifier.padding(padding))
            else -> ReportsScreen(Modifier.padding(padding))
        }
    }
}

@Composable
fun OperationsScreen(modifier: Modifier = Modifier) {
    val kpis = MockRepository.kpis
    val red = kpis.count { it.progress < 80 }
    val yellow = kpis.count { it.progress in 80.0..94.99 }
    val green = kpis.count { it.progress >= 95 }
    val overdue = MockRepository.tasks.count { it.status == TaskStatus.OVERDUE }

    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Tổng quan hôm nay", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Ưu tiên xử lý chỉ tiêu rủi ro và công việc quá hạn.", color = Color.Gray)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("Đỏ", red.toString(), Color(0xFFD32F2F), Modifier.weight(1f))
                StatCard("Vàng", yellow.toString(), Color(0xFFF9A825), Modifier.weight(1f))
                StatCard("Xanh", green.toString(), Color(0xFF2E7D32), Modifier.weight(1f))
                StatCard("Quá hạn", overdue.toString(), Color(0xFF6A1B9A), Modifier.weight(1f))
            }
        }
        item { SectionTitle("Cảnh báo cần bám đuổi") }
        items(kpis.sortedBy { it.progress }.take(3)) { KpiRow(it) }
        item { SectionTitle("Việc trọng tâm") }
        items(MockRepository.tasks.take(4)) { TaskRow(it) }
    }
}

@Composable
fun KpiScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Dashboard KPI", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Ngưỡng mặc định: Đỏ <80% • Vàng 80–<95% • Xanh ≥95%", color = Color.Gray, fontSize = 12.sp)
        }
        items(MockRepository.kpis) { KpiRow(it) }
    }
}

@Composable
fun TasksScreen(modifier: Modifier = Modifier) {
    LazyColumn(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Giao việc & Deadline", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("Theo dõi đầu mối, trạng thái và việc quá hạn.", color = Color.Gray)
        }
        items(MockRepository.tasks) { TaskRow(it) }
    }
}

@Composable
fun ReportsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Báo cáo nhanh", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("MVP đang dùng dữ liệu mẫu. Khi nối Google Sheets/API, màn hình này sẽ sinh báo cáo KPI ngày/tuần từ dữ liệu thật.", color = Color.Gray)
        ReportCard("Báo cáo KPI ngày", "Tổng hợp tiến độ • cảnh báo • giao việc", Icons.Default.Today)
        ReportCard("Báo cáo KPI tuần", "So sánh kế hoạch tuần và thực hiện", Icons.Default.DateRange)
        ReportCard("Danh sách cảnh báo", "KPI dưới ngưỡng và nhiệm vụ quá hạn", Icons.Default.Warning)
    }
}

@Composable
fun StatCard(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(modifier, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontWeight = FontWeight.Black, fontSize = 22.sp, color = accent)
            Text(title, fontSize = 10.sp, color = Color.Gray)
        }
    }
}

@Composable
fun KpiRow(kpi: KpiItem) {
    val p = kpi.progress
    val color = when { p < 80 -> Color(0xFFD32F2F); p < 95 -> Color(0xFFF9A825); else -> Color(0xFF2E7D32) }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(kpi.name, fontWeight = FontWeight.Bold)
                    Text("${kpi.owner} • KH ${fmt(kpi.plan)} ${kpi.unit} • TH ${fmt(kpi.actual)} ${kpi.unit}", fontSize = 12.sp, color = Color.Gray)
                }
                Text("${p.roundToInt()}%", fontWeight = FontWeight.Black, color = color, fontSize = 18.sp)
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { (p.coerceIn(0.0, 100.0) / 100.0).toFloat() },
                modifier = Modifier.fillMaxWidth().height(8.dp),
                color = color,
                trackColor = color.copy(alpha = 0.15f)
            )
        }
    }
}

@Composable
fun TaskRow(task: WorkItem) {
    val statusText = when(task.status) { TaskStatus.TODO -> "Chưa làm"; TaskStatus.DOING -> "Đang làm"; TaskStatus.DONE -> "Hoàn thành"; TaskStatus.OVERDUE -> "Quá hạn" }
    val color = when(task.status) { TaskStatus.TODO -> Color.Gray; TaskStatus.DOING -> Color(0xFF1565C0); TaskStatus.DONE -> Color(0xFF2E7D32); TaskStatus.OVERDUE -> Color(0xFFD32F2F) }
    Card(shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(task.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                AssistChip(onClick = {}, label = { Text(statusText, color = color, fontSize = 11.sp) })
            }
            Text("${task.owner} • Deadline: ${task.deadline} • ${task.priority}", fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun SectionTitle(text: String) { Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp) }

@Composable
fun ReportCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column { Text(title, fontWeight = FontWeight.Bold); Text(subtitle, fontSize = 12.sp, color = Color.Gray) }
        }
    }
}

private fun fmt(v: Double): String = if (v % 1.0 == 0.0) v.toInt().toString() else String.format("%.1f", v)

package com.viettel.caobang.dieuhanh.data

object MockRepository {
    val kpis = listOf(
        KpiItem("FTTH", 420.0, 351.0, "TB", "Kênh B2C"),
        KpiItem("Di động", 680.0, 612.0, "TB", "Kênh B2C"),
        KpiItem("Doanh nghiệp số", 1250.0, 1065.0, "triệu", "GĐ Cụm KHDN"),
        KpiItem("Tendoo", 160.0, 119.0, "KH", "DNS"),
        KpiItem("Năng suất bán hàng", 67.0, 61.4, "triệu/AM", "AM đại trà")
    )

    val tasks = listOf(
        WorkItem("Rà soát KPI ngày và chốt danh sách cảnh báo", "Phòng Kinh doanh", "17:00 hôm nay", TaskStatus.DOING, "Cao"),
        WorkItem("Bám đuổi FTTH nhóm dưới 80%", "GĐVTKV", "18:00 hôm nay", TaskStatus.TODO, "Cao"),
        WorkItem("Đẩy doanh thu DNS theo cụm", "GĐ Cụm KHDN", "20:00 hôm nay", TaskStatus.DOING, "Cao"),
        WorkItem("Cập nhật báo cáo cuối ngày", "Đầu mối báo cáo", "21:00 hôm nay", TaskStatus.TODO, "Trung bình"),
        WorkItem("Khắc phục tồn triển khai quá hạn", "Đơn vị liên quan", "Hôm qua", TaskStatus.OVERDUE, "Khẩn")
    )
}
